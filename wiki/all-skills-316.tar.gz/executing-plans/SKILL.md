---
name: "executing-plans"
description: "想法一堆但不知道从哪下手？帮你拆成一步步能直接干的任务。Invoke when user has a written implementation plan to execute in a separate session with review checkpoints."
---

# Executing Plans

## 功能
想法一堆但不知道从哪下手？帮你拆成一步步能直接干的任务。

## 使用场景
- 将想法落地为行动
- 任务拆解
- 执行计划制定
- 项目管理
- 多步骤任务执行

## 使用方法
当用户需要执行任务时：
1. 梳理用户的整体目标和想法
2. 拆分为具体可执行的步骤
3. 确定优先级和依赖关系
4. 设定检查点和验收标准
5. 跟踪执行进度并调整
