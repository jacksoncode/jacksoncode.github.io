---
name: "vercel-composition-patterns"
description: "和 React 最佳实践是一套的，专治组件写着写着变臃肿的问题，配合用效果更好。Invoke when refactoring components with boolean prop proliferation, building flexible component libraries, or designing reusable APIs."
---

# Vercel Composition Patterns

## 功能
和 React 最佳实践是一套的，专治组件写着写着变臃肿的问题，配合用效果更好。

## 使用场景
- 组件库设计
- 解决布尔属性泛滥问题
- 构建灵活的组件 API
- 复合组件模式
- 渲染 props 和上下文提供者

## 使用方法
当用户设计组件时：
1. 使用复合组件模式替代布尔属性
2. 设计灵活的组件组合方式
3. 使用 render props 或 children 作为函数
4. 通过上下文提供者共享状态
5. 保持组件 API 简洁和可扩展
