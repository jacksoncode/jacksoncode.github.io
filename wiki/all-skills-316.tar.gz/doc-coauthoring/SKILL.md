---
name: "doc-coauthoring"
description: "Guide users through a structured workflow for co-authoring documentation. Use when user wants to write documentation, proposals, technical specs, decision docs, or similar structured content."
---

# Doc Coauthoring

## 功能
Anthropic 官方出品。引导用户通过结构化工作流协作撰写文档。

## 使用场景
- 文档协作撰写
- 提案编写
- 技术规格文档
- 决策文档
- 结构化内容创作

## 使用方法
当用户需要协作写文档时：
1. 引导用户明确文档目标
2. 建立文档结构和大纲
3. 逐步填充内容
4. 迭代优化和审阅
5. 输出最终文档
