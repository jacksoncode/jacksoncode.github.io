---
name: "nightly-runner"
description: "重复任务交给定时巡检。Invoke when user needs to set up scheduled, recurring tasks or automated nightly checks."
---

# Nightly Runner

## 功能
重复任务交给定时巡检。自动化执行定期任务。

## 使用场景
- 定时任务执行
- 夜间巡检
- 自动化检查
- 定期报告生成
- 重复工作自动化

## 使用方法
当用户需要定时任务时：
1. 定义任务内容和频率
2. 设置执行时间表
3. 配置通知和报告
4. 监控任务执行
5. 处理异常和告警
