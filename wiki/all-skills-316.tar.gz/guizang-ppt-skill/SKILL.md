---
name: "guizang-ppt-skill"
description: "PPT、演讲图、公众号头图、小红书封面制作工具。适合把文章观点做成PPT，或将长文二次分成分享稿、演示稿或视觉卡片。Invoke when user wants to turn article content into PPT, presentation slides, or visual cards for sharing."
---

# guizang-ppt-skill

## 功能
适合把文章观点做成 PPT、演讲图、公众号头图、小红书封面。如果你经常把一篇文章二次分成分享稿、演示稿或者视觉卡片，这个会很顺手。

## 使用场景
- 文章观点转PPT
- 演讲/分享演示稿
- 公众号头图
- 小红书封面
- 视觉卡片
- 内容二次分发

## 使用方法
当用户需要制作PPT或演示内容时：
1. 提取文章中的核心观点和关键信息
2. 设计适合演示的页面结构
3. 每页聚焦一个核心观点
4. 配合简洁有力的视觉设计
5. 生成可直接使用的PPT或演示文稿
