---
name: "hermes-webui"
description: "轻量 WebUI 设计，访问体验丝滑，用过就回不去。Invoke when user needs lightweight web UI design, smooth user experience, or modern interface components."
---

# Hermes WebUI

## 功能
轻量 WebUI 设计，访问体验丝滑，用过就回不去。4.6K 星高赞技能。

## 使用场景
- Web UI 设计
- 用户体验优化
- 轻量级界面
- 现代组件设计
- 流畅交互

## 使用方法
当用户需要 WebUI 时：
1. 设计轻量界面
2. 优化用户体验
3. 实现流畅交互
4. 确保响应速度
5. 提供现代化视觉效果
