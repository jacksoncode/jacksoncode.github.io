---
name: "test-driven-development"
description: "强制 CC 先写测试再写代码，代码质量有保障，出自 67k 星的 superpowers。Invoke when implementing any feature or bugfix, before writing implementation code."
---

# Test Driven Development

## 功能
强制 CC 先写测试再写代码，代码质量有保障，出自 67k 星的 superpowers。

## 使用场景
- 新功能开发
- Bug 修复
- 代码重构
- 确保代码质量
- 提高测试覆盖率

## 使用方法
当用户开发功能时：
1. 先编写失败的测试用例
2. 编写最小代码使测试通过
3. 重构代码保持测试通过
4. 重复红-绿-重构循环
5. 确保每个功能都有测试覆盖
