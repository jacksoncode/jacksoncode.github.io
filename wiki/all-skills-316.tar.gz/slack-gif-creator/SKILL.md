---
name: "slack-gif-creator"
description: "Generate animated GIFs optimized for Slack. Invoke when user needs to create animated GIF images for Slack messages or notifications."
---

# Slack GIF Creator

## 功能
Anthropic 官方出品。生成针对 Slack 优化的动画 GIF。

## 使用场景
- Slack 动画 GIF
- 团队通知动画
- 表情包制作
- 消息增强
- 轻量动画内容

## 使用方法
当用户需要 GIF 时：
1. 理解用户需求
2. 生成适合 Slack 的动画
3. 优化文件大小和尺寸
4. 确保在 Slack 中正常显示
