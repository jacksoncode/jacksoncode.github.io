---
name: "sequential-thinking"
description: "思维链推理。Invoke when user needs step-by-step reasoning, logical deduction, or structured problem-solving."
---

# Sequential Thinking

## 功能
思维链推理。通过逐步推理解决复杂问题。

## 使用场景
- 复杂问题分析
- 逻辑推理
- 步骤化解题
- 决策分析
- 因果推理

## 使用方法
当用户需要推理时：
1. 分解问题为步骤
2. 逐步分析和推理
3. 验证每一步的逻辑
4. 综合得出结论
5. 确保推理过程清晰可追溯
