---
name: "tushare-openclaw-skill"
description: "A股数据源。提供A股数据、财报/回测数据拉取。Invoke when user needs to fetch A-share stock data, financial reports, or backtesting data from Tushare or similar data sources."
---

# Tushare OpenClaw Skill

## 功能
提供 A 股数据、财报/回测数据拉取。

## 使用场景
- 获取 A 股实时/历史数据
- 拉取财务报表数据
- 获取回测所需数据
- 数据分析和处理
- 量化策略数据支持

## 使用方法
当用户需要 A 股数据时：
1. 通过 Tushare 等接口获取数据
2. 整理成结构化格式
3. 提供数据清洗和预处理
4. 支持多种数据类型（行情、财务、因子）
5. 确保数据准确性和完整性
