---
name: "obsidian-bases"
description: "Create and edit Obsidian Bases (.base files) with views, filters, formulas, and summaries. Use when working with .base files, creating database-like views of notes, or when the user mentions Bases, table views, card views, filters, or formulas in Obsidian."
---

# Obsidian Bases

## 功能
创建和编辑 Obsidian Bases (.base 文件)，支持视图、过滤器、公式和摘要。

## 使用场景
- Obsidian Bases 创建
- 数据库视图
- 表格视图
- 卡片视图
- 过滤器和公式

## 使用方法
当用户需要 Obsidian Bases 时：
1. 创建 .base 文件
2. 设计视图和过滤器
3. 添加公式和摘要
4. 创建数据库风格的笔记视图
5. 优化数据展示
