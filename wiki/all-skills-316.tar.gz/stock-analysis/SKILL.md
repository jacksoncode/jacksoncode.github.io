---
name: "stock-analysis"
description: "股票分析。个股基本面+技术面一键拆解，盘前机会挖掘。Invoke when user needs to analyze individual stocks, evaluate fundamentals, technical indicators, or find pre-market opportunities."
---

# Stock Analysis

## 功能
个股基本面+技术面一键拆解，盘前机会挖掘。

## 使用场景
- 个股基本面分析
- 技术面分析
- 盘前机会挖掘
- 投资价值评估
- 买卖时机判断

## 使用方法
当用户需要分析股票时：
1. 收集个股基本面数据（财务、行业、竞争力）
2. 分析技术面指标（K线、均线、成交量）
3. 评估估值水平
4. 挖掘盘前交易机会
5. 给出综合分析和建议
