---
name: "docs-whisperer"
description: "README、注释、变更说明同步生成。Invoke when user needs to generate or synchronize documentation including README, code comments, and changelogs."
---

# Docs Whisperer

## 功能
README、注释、变更说明同步生成。自动化文档维护和同步。

## 使用场景
- README 自动生成
- 代码注释维护
- 变更说明同步
- 文档一致性检查
- 多文档联动更新

## 使用方法
当用户需要生成文档时：
1. 分析代码和项目结构
2. 生成或更新 README
3. 同步代码注释
4. 生成变更说明
5. 确保文档间一致性
