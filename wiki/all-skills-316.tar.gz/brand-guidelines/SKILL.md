---
name: "brand-guidelines"
description: "Applies Anthropic's official brand colors and typography to any sort of artifact that may benefit from having Anthropic's look-and-feel. Use it when brand colors or style guidelines, visual formatting, or company design standards apply."
---

# Brand Guidelines

## 功能
Anthropic 官方出品。应用 Anthropic 官方品牌色彩和字体到各种产出物上。

## 使用场景
- 应用 Anthropic 品牌风格
- 品牌色彩匹配
- 字体规范
- 视觉格式化
- 公司设计标准

## 使用方法
当用户需要品牌设计时：
1. 应用 Anthropic 官方色彩方案
2. 使用规定的字体和排版
3. 确保视觉一致性
4. 遵循品牌设计标准
