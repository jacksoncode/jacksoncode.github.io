---
name: "html-deck"
description: "Create stunning, animation-rich HTML slide decks from scratch. Outputs a self-contained HTML file that opens in any browser, agent-friendly, visually impressive and pixel-perfect across all platforms. Use when the user wants to build a brand-new presentation from a topic, outline, document, or Markdown."
---

# HTML Deck

## 功能
从零创建令人惊叹、动画丰富的 HTML 幻灯片。输出自包含的 HTML 文件，可在任何浏览器中打开，跨平台像素级完美。

## 使用场景
- 演示文稿
- 幻灯片
- 主题演讲
- 多幻灯片文档
- 从零创建演示

## 使用方法
当用户需要演示时：
1. 基于主题或大纲构建
2. 设计动画丰富的幻灯片
3. 确保自包含和跨平台兼容
4. 提供视觉震撼的效果
5. 输出可直接使用的 HTML 文件
