---
name: "dependency-guard"
description: "升级依赖前先看破坏面。Invoke when user needs to assess the impact of dependency upgrades before applying them."
---

# Dependency Guard

## 功能
升级依赖前先看破坏面。评估依赖升级的影响范围。

## 使用场景
- 依赖升级评估
- 破坏性变更检测
- 兼容性检查
- 升级风险分析
- 依赖管理

## 使用方法
当用户需要升级依赖时：
1. 分析当前依赖版本
2. 检查新版本变更
3. 评估破坏性影响
4. 识别需要修改的代码
5. 提供升级建议
