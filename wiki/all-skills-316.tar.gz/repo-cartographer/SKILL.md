---
name: "repo-cartographer"
description: "先画代码地图，再决定从哪动手。Invoke when user needs to understand codebase structure, map dependencies, or plan refactoring before making changes."
---

# Repo Cartographer

## 功能
先画代码地图，再决定从哪动手。帮助理解代码库结构和依赖关系。

## 使用场景
- 新代码库探索
- 代码结构分析
- 依赖关系映射
- 重构规划
- 代码导航

## 使用方法
当用户需要理解代码库时：
1. 扫描代码库结构
2. 绘制模块依赖图
3. 识别关键组件和边界
4. 标注热点和复杂区域
5. 提供修改建议和切入点
