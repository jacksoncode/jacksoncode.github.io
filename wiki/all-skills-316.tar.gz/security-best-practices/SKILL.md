---
name: "security-best-practices"
description: "Perform language and framework specific security best-practice reviews and suggest improvements. Trigger only when user explicitly requests security best practices guidance, a security review/report, or secure-by-default coding help."
---

# Security Best Practices

## 功能
执行语言和框架特定的安全最佳实践审查，提出改进建议。支持 Python、JavaScript/TypeScript、Go。

## 使用场景
- 安全最佳实践指导
- 安全审查/报告
- 安全编码帮助
- 漏洞检测
- 安全加固

## 使用方法
当用户需要安全审查时：
1. 分析代码中的安全风险
2. 识别常见漏洞模式
3. 提供安全改进建议
4. 推荐安全编码实践
5. 生成安全审查报告
