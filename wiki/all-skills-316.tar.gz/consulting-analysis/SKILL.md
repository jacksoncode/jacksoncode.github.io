---
name: "consulting-analysis"
description: "Use this skill when the user requests to generate, create, or write professional research reports including but not limited to market analysis, consumer insights, brand analysis, financial analysis, industry research, competitive intelligence, investment due diligence, or any consulting-grade analytical report."
---

# Consulting Analysis

## 功能
生成专业研究报告，包括市场分析、消费者洞察、品牌分析、财务分析、行业研究、竞争情报、投资尽职调查等咨询级分析报告。

## 使用场景
- 市场分析
- 消费者洞察
- 品牌分析
- 财务分析
- 行业研究
- 竞争情报
- 投资尽职调查

## 使用方法
当用户需要咨询报告时：
1. 生成结构化分析框架
2. 收集和整理数据
3. 制作专业报告
4. 嵌入图表和可视化
5. 提供战略洞察
