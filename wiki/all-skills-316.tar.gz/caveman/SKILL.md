---
name: "caveman"
description: "大幅压缩 token 消耗，省钱又提速。通过压缩 prompt 来减少 token 使用量，让上下文窗口容纳更多有效内容。Invoke when user wants to reduce token consumption, lower API costs, or optimize Claude Code performance."
---

# Caveman

## 功能
大幅压缩 token 消耗，省钱又提速。通过压缩 prompt 来减少 token 使用量，让上下文窗口容纳更多有效内容。GitHub 53.6K Stars 高赞项目。

## 使用场景
- Token 消耗优化
- API 成本降低
- 上下文窗口优化
- 高频使用场景
- 长对话优化

## 使用方法
当用户需要优化 token 时：
1. 分析当前 prompt 结构
2. 识别可压缩的部分
3. 压缩冗余信息
4. 保留关键指令
5. 显著降低 token 使用量
