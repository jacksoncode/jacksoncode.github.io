---
name: "maestro"
description: "复盘优化。Invoke when user needs to review past work, analyze performance, or optimize processes based on retrospectives."
---

# Maestro

## 功能
复盘优化。帮助用户回顾工作并进行持续改进。

## 使用场景
- 工作复盘
- 性能分析
- 流程优化
- 经验总结
- 持续改进

## 使用方法
当用户需要复盘优化时：
1. 回顾完成的任务
2. 分析成功和失败因素
3. 识别改进机会
4. 制定优化方案
5. 建立持续改进机制
