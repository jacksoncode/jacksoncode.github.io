---
name: "tailwind-design-system"
description: "Tailwind CSS 设计系统。做前端的配合着用效果很好，提供一致的设计语言和组件规范。Invoke when building with Tailwind CSS, creating component libraries, or designing with utility-first CSS approach."
---

# Tailwind Design System

## 功能
Tailwind CSS 设计系统。做前端的配合着用效果很好，提供一致的设计语言和组件规范。

## 使用场景
- 使用 Tailwind CSS 构建项目
- 创建组件库
- 设计系统搭建
- Utility-first CSS 开发
- 保持设计一致性

## 使用方法
当用户使用 Tailwind CSS 时：
1. 遵循 Tailwind 的设计原则和命名规范
2. 使用预设的颜色、间距、字体系统
3. 创建可复用的组件样式
4. 确保响应式设计
5. 保持代码整洁和一致性
