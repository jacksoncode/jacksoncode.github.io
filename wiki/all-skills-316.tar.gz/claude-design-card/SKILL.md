---
name: "claude-design-card"
description: "一个Claude Skill搞定公众号封面、小红书图文、视频封面。28种布局、10种主题，自媒体人的设计自由。Invoke when user needs to generate visual cards for WeChat covers, Xiaohongshu posts, Bilibili covers, tutorial steps, comparison cards, or quote cards."
---

# Claude Design Card

## 功能
一个 Claude Skill 搞定公众号封面、小红书图文、视频封面。28种布局、10种主题配色，自媒体人的设计自由。

## 使用场景
- 公众号封面图（头条两图+次条）
- 小红书图文卡片（支持多张连排）
- 教程步骤卡
- 对比/评测卡
- 金句分享卡
- 数据高亮卡
- B站/YouTube视频封面

## 使用方法
当用户需要设计卡片时：
1. 输入文章标题、核心观点或链接
2. 选择卡片类型和主题配色
3. 自动匹配最合适的布局组合
4. 生成可直接发布的视觉卡片
5. 支持精确调整字号、配色、间距等细节
