---
name: "hindsight"
description: "长期记忆层 — 语义 + 图谱 + 时间三维检索。社区公认'第一个要装的 skill'，让 Hermes 记住所有对话不再失忆。Invoke when user needs persistent memory, context retention, or advanced retrieval across conversations."
---

# Hindsight

## 功能
长期记忆层 — 语义 + 图谱 + 时间三维检索。社区公认"第一个要装的 skill"，让 Hermes 记住所有对话不再失忆。

## 使用场景
- 长期记忆保持
- 语义检索
- 知识图谱
- 时间线检索
- 对话上下文保持

## 使用方法
当用户需要记忆时：
1. 存储对话和知识
2. 建立语义索引
3. 构建知识图谱
4. 支持时间维度检索
5. 确保信息不丢失
