---
name: "theme-factory"
description: "Toolkit for styling artifacts with a theme. These artifacts can be slides, docs, reportings, HTML landing pages, etc. There are 10 pre-set themes with colors/fonts that you can apply to any artifact that has been creating, or can generate a new theme on-the-fly."
---

# Theme Factory

## 功能
Anthropic 官方出品。为幻灯片、文档、报告、HTML 页面等产出物提供主题样式工具包。10 个预设主题，也可即时生成新主题。

## 使用场景
- 幻灯片主题
- 文档样式
- 报告美化
- HTML 页面主题
- 自定义主题生成

## 使用方法
当用户需要主题时：
1. 选择预设主题或生成新主题
2. 应用色彩和字体方案
3. 确保风格一致性
4. 支持多种产出物类型
