---
name: "guizang-social-card-skill"
description: "小红书图文和公众号封面制作工具。把一篇长文拆成多张卡片，做成可以直接分发的视觉内容。Invoke when user wants to turn a long article into multiple social media cards for Xiaohongshu or WeChat."
---

# guizang-social-card-skill

## 功能
写完文章之后，可以用它做小红书图文和公众号封面。一篇长文拆成多张卡片，做成可以直接分发的视觉内容，会省很多时间。

## 使用场景
- 小红书图文制作
- 公众号封面图
- 长文拆分为多张卡片
- 社交媒体视觉内容
- 可分发的朋友圈/社群素材

## 使用方法
当用户需要制作社交卡片时：
1. 分析长文的核心内容和结构
2. 将内容拆分为适合单张卡片展示的模块
3. 设计统一的视觉风格
4. 生成多张卡片，每张有明确的主题
5. 确保卡片适合在小红书、公众号等平台分发
