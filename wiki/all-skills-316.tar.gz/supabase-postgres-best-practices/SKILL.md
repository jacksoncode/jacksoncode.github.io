---
name: "supabase-postgres-best-practices"
description: "Supabase 官方出品，写数据库不踩坑，查询优化、安全策略都帮你兜住了。Invoke when working with Supabase, PostgreSQL, database design, query optimization, or security policies."
---

# Supabase Postgres Best Practices

## 功能
Supabase 官方出品，写数据库不踩坑，查询优化、安全策略都帮你兜住了。

## 使用场景
- Supabase 数据库开发
- PostgreSQL 查询优化
- 数据库安全策略
- 实时订阅配置
- 身份验证和授权

## 使用方法
当用户使用 Supabase 时：
1. 设计合理的数据库结构
2. 优化查询性能
3. 配置 RLS（行级安全）策略
4. 使用实时订阅功能
5. 确保数据安全和访问控制
