---
name: "claude-mem"
description: "Claude跨会话记忆。自动记录Claude做的每一件事，下次启动自动加载。Invoke when user needs persistent memory across Claude Code sessions, project preferences tracking, or historical context retention."
---

# Claude Mem

## 功能
Claude 跨会话记忆。自动记录 Claude 做的每一件事，下次启动自动加载。63K Stars 高赞技能。再也不用每次开新会话都重新介绍项目了。

## 使用场景
- 跨会话记忆保持
- 项目偏好记录
- 历史上下文恢复
- 常用写法记忆
- Token 节省

## 使用方法
当用户需要记忆时：
1. 自动记录每次交互
2. 保存项目偏好和设置
3. 记住踩过的坑和解决方案
4. 下次启动自动加载
5. 持续积累个人知识库
