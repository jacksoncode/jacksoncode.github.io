---
name: "decision-log"
description: "重要取舍写下来，未来少考古。Invoke when user needs to document important technical decisions, trade-offs, and rationale for future reference."
---

# Decision Log

## 功能
重要取舍写下来，未来少考古。记录关键决策和理由。

## 使用场景
- 技术决策记录
- 方案取舍说明
- 架构决策文档
- 历史原因追溯
- 知识传承

## 使用方法
当用户需要做决策时：
1. 记录决策背景和问题
2. 列出可选方案
3. 分析各方案优劣
4. 记录最终决策和理由
5. 存档供未来参考
