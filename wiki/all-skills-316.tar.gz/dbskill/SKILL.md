---
name: "dbskill"
description: "内容诊断工具。适合做选题判断、商业表达、hook、小红书标题、爆款拆解，尤其适合中文自媒体和知识型创作者。Invoke when user needs content strategy analysis, title optimization, hook writing, or viral content breakdown for Chinese social media."
---

# dbskill

## 功能
更像一个内容诊断工具。适合做选题判断、商业表达、hook、小红书标题、爆款拆解，尤其适合中文自媒体和知识型创作者。

## 使用场景
- 判断一个选题是否值得做
- 优化商业表达和转化文案
- 写吸引人的 hook（开头钩子）
- 生成小红书风格标题
- 拆解爆款内容的结构和逻辑
- 内容策略分析和建议

## 使用方法
当用户需要内容诊断时：
1. 分析内容的选题价值、目标受众、竞争度
2. 评估商业表达是否清晰有力
3. 优化或重写 hook，确保前3秒能抓住注意力
4. 生成多个小红书风格标题供选择
5. 拆解爆款内容的结构，提取可复用的模式
