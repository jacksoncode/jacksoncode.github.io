---
name: "docx"
description: "Word文档一键生成。Invoke when user needs to create, edit, or generate Word documents (.docx) programmatically."
---

# Docx

## 功能
Word文档一键生成，支持自动化创建和编辑 Word 文档。

## 使用场景
- Word 文档自动生成
- 报告和合同生成
- 文档模板处理
- 批量文档创建
- 文档格式转换

## 使用方法
当用户需要生成 Word 文档时：
1. 收集文档内容和结构需求
2. 设计文档模板和样式
3. 自动生成 Word 文档
4. 支持表格、图片、样式等元素
5. 提供下载或保存选项
