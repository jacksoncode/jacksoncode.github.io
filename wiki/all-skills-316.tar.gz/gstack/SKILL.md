---
name: "gstack"
description: "优化记忆层，让 Hermes 学会自我进化，越用越聪明。Invoke when user needs advanced memory optimization, self-improvement capabilities, or intelligent learning systems."
---

# GStack

## 功能
优化记忆层，让 Hermes 学会自我进化，越用越聪明。85K 星高赞技能。

## 使用场景
- 记忆层优化
- 自我进化
- 智能学习
- 性能提升
- 自适应改进

## 使用方法
当用户需要优化记忆时：
1. 分析当前记忆结构
2. 优化记忆存储和检索
3. 启用自我学习机制
4. 持续进化改进
5. 提升整体智能水平
