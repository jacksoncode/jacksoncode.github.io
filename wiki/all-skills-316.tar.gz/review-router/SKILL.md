---
name: "review-router"
description: "不同模块自动找最懂的人看。Invoke when user needs to route code reviews to the most appropriate team members based on expertise and module ownership."
---

# Review Router

## 功能
不同模块自动找最懂的人看。智能分配代码审查任务。

## 使用场景
- 代码审查分配
- 模块专家匹配
- 审查效率优化
- 团队负载均衡
- 专业知识利用

## 使用方法
当用户需要分配审查时：
1. 分析代码变更的模块
2. 识别相关领域专家
3. 自动分配审查任务
4. 考虑审查者负载
5. 确保审查质量
