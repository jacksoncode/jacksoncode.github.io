---
name: "byted-seedance-video-generate"
description: "Generate videos using Seedance models. Invoke when user wants to create videos from text prompts, images, or reference materials."
---

# Byted Seedance Video Generate

## 功能
使用 Seedance 模型生成视频。支持从文本提示、图片或参考材料创建视频。

## 使用场景
- 文本生成视频
- 图片生成视频
- 参考材料生成视频
- AI 视频创作
- 视频内容生成

## 使用方法
当用户需要生成视频时：
1. 理解用户的视频需求
2. 准备输入材料（文本/图片/参考）
3. 使用 Seedance 模型生成
4. 调整视频参数
5. 输出高质量视频
