---
name: "github"
description: "Issue/PR/CI 一站式。Invoke when user needs to manage GitHub repositories, issues, pull requests, or CI/CD workflows."
---

# GitHub

## 功能
Issue/PR/CI 一站式管理，通过命令行或 API 操作 GitHub。

## 使用场景
- 仓库管理
- Issue 创建和跟踪
- Pull Request 管理
- CI/CD 工作流配置
- 代码审查

## 使用方法
当用户需要操作 GitHub 时：
1. 认证并连接到 GitHub API
2. 管理仓库、Issue、PR
3. 配置 CI/CD 工作流
4. 执行代码审查和合并
5. 返回操作结果和状态
