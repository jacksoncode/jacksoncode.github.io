---
name: "mcp-builder"
description: "四阶段引导，从零写 MCP Server 不再踩坑。Invoke when user wants to create high-quality MCP (Model Context Protocol) servers that enable LLMs to interact with external services."
---

# MCP Builder

## 功能
四阶段引导，从零写 MCP Server 不再踩坑。帮助用户创建高质量的 MCP 服务器。

## 使用场景
- MCP Server 开发
- 外部服务集成
- LLM 工具扩展
- API 封装
- 自定义功能开发

## 使用方法
当用户需要创建 MCP Server 时：
1. 第一阶段：需求分析和设计
2. 第二阶段：核心功能实现
3. 第三阶段：测试和验证
4. 第四阶段：部署和优化
5. 确保 Server 稳定可靠
