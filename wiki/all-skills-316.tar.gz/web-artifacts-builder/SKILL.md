---
name: "web-artifacts-builder"
description: "Suite of tools for creating elaborate, multi-component claude.ai HTML artifacts using modern frontend web technologies (React, Tailwind CSS, shadcn/ui). Use for complex artifacts requiring state management, routing, or shadcn/ui components - not for simple single-file HTML/JSX artifacts."
---

# Web Artifacts Builder

## 功能
Anthropic 官方出品。使用 React、Tailwind CSS、shadcn/ui 创建复杂的多组件 HTML artifacts。

## 使用场景
- 复杂 Web 组件
- 多组件交互界面
- 状态管理
- 路由功能
- shadcn/ui 组件使用

## 使用方法
当用户需要复杂 Web 组件时：
1. 分析组件需求
2. 使用 React + Tailwind CSS
3. 集成 shadcn/ui 组件
4. 实现状态管理和路由
5. 输出完整的 HTML artifact
