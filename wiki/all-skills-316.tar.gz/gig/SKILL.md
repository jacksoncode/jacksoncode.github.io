---
name: "gig"
description: "Google 全家桶 CLI。Invoke when user needs to interact with Google services (Gmail, Drive, Calendar, etc.) from command line."
---

# Gig

## 功能
Google 全家桶 CLI，通过命令行操作 Google 各项服务。

## 使用场景
- Gmail 邮件管理
- Google Drive 文件操作
- Google Calendar 日程管理
- Google Docs 文档处理
- Google Sheets 表格操作

## 使用方法
当用户需要操作 Google 服务时：
1. 认证并连接到 Google API
2. 执行相应的 CLI 命令
3. 处理邮件、文件、日程等
4. 返回操作结果
5. 支持批量和自动化操作
