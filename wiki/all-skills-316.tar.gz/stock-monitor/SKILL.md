---
name: "stock-monitor"
description: "自选股监控。持仓异动/事件驱动自动预警。Invoke when user needs to monitor watchlist stocks, track portfolio changes, or receive alerts on stock movements and events."
---

# Stock Monitor / Stock Watcher

## 功能
持仓异动/事件驱动自动预警。

## 使用场景
- 自选股实时监控
- 持仓异动预警
- 事件驱动提醒
- 价格触发通知
- 新闻公告监控

## 使用方法
当用户需要监控股票时：
1. 设置监控标的和条件
2. 实时跟踪价格和成交量变化
3. 监控相关新闻和公告
4. 触发预警时及时通知
5. 提供异动原因分析
