---
name: "self-evolution"
description: "创始人 Teknium 亲写的自进化增强版，官方背书。Invoke when user needs self-evolving capabilities, autonomous improvement, or advanced adaptive systems."
---

# Self Evolution

## 功能
创始人 Teknium 亲写的自进化增强版，官方背书。2.4K 星高赞技能。

## 使用场景
- 自进化能力
- 自主改进
- 自适应系统
- 智能增强
- 持续优化

## 使用方法
当用户需要自进化时：
1. 启用自进化机制
2. 监控性能和表现
3. 自动识别改进点
4. 执行优化策略
5. 持续提升能力
