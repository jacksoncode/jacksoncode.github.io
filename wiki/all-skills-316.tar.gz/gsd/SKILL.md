---
name: "gsd"
description: "规范驱动开发，少扯皮多干活。Invoke when working on complex project delivery, need structured development workflow, or want to enforce coding standards and reduce unnecessary discussions."
---

# GSD (Get Shit Done)

## 功能
规范驱动开发，少扯皮多干活。7.7K Stars 高赞技能。帮助团队在复杂项目中高效交付。

## 使用场景
- 复杂项目交付
- 规范驱动开发
- 减少无效沟通
- 提高开发效率
- 团队协作优化

## 使用方法
当用户需要高效开发时：
1. 明确项目规范和标准
2. 建立清晰的开发流程
3. 减少不必要的讨论
4. 聚焦核心交付目标
5. 确保高质量输出
