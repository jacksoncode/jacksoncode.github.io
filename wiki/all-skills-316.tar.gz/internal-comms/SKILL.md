---
name: "internal-comms"
description: "A set of resources to help me write all kinds of internal communications, using the formats that my company likes to use. Claude should use this skill whenever asked to write some sort of internal communications (status reports, leadership updates, 3P updates, company newsletters, FAQs, incident reports, project updates, etc.)."
---

# Internal Comms

## 功能
Anthropic 官方出品。帮助撰写各种内部沟通文档，使用公司惯用的格式。

## 使用场景
- 状态报告
- 领导层更新
- 公司通讯
- FAQ 文档
- 事件报告
- 项目更新

## 使用方法
当用户需要内部沟通时：
1. 确定沟通类型和受众
2. 使用合适的格式模板
3. 撰写清晰专业的内部文档
4. 确保语气和风格得体
