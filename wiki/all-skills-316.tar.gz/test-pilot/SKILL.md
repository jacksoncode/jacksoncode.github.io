---
name: "test-pilot"
description: "单测、集成、快照一起护航。Invoke when user needs comprehensive testing strategy including unit tests, integration tests, and snapshot tests."
---

# Test Pilot

## 功能
单测、集成、快照一起护航。提供全方位的测试策略。

## 使用场景
- 单元测试编写
- 集成测试设计
- 快照测试维护
- 测试覆盖率提升
- 自动化测试流程

## 使用方法
当用户需要测试时：
1. 分析代码确定测试策略
2. 编写单元测试覆盖核心逻辑
3. 设计集成测试验证交互
4. 添加快照测试防止UI回归
5. 确保测试全面且可维护
