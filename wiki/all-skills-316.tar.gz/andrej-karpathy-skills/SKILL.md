---
name: "andrej-karpathy-skills"
description: "Karpathy的LLM编程四原则。编码前先思考、简单性优先、精准变更、目标驱动执行。Invoke when user wants to improve AI-assisted coding quality, learn best practices from Andrej Karpathy, or apply structured LLM programming principles."
---

# Andrej Karpathy Skills

## 功能
AI 大神 Karpathy 总结的 LLM 编程四大原则，浓缩在一个文件中。60K Stars 高赞技能。编码前先思考、简单性优先、精准变更、目标驱动执行。

## 使用场景
- 提升 AI 辅助编程质量
- 学习 Karpathy 编程原则
- 结构化 LLM 编程
- 代码质量提升
- 新手入门指导

## 使用方法
当用户写代码时：
1. 编码前先思考需求和方案
2. 坚持简单性优先原则
3. 做精准变更，避免过度修改
4. 目标驱动执行
5. 持续优化代码质量
