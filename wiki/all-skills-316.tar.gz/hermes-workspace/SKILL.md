---
name: "hermes-workspace"
description: "Web GUI 界面 — 聊天 + 终端 + Skill 管理三合一。不想敲命令行的直接装，浏览器里管理所有操作。Invoke when user needs a web-based GUI for chat, terminal, and skill management."
---

# Hermes Workspace

## 功能
Web GUI 界面 — 聊天 + 终端 + Skill 管理三合一。不想敲命令行的直接装，浏览器里管理所有操作。

## 使用场景
- Web 界面管理
- 聊天交互
- 终端操作
- Skill 管理
- 可视化控制

## 使用方法
当用户需要 GUI 时：
1. 启动 Web 界面
2. 提供聊天交互功能
3. 集成终端操作
4. 管理 Skill 配置
5. 在浏览器中完成所有操作
