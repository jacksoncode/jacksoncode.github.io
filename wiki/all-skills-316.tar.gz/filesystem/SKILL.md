---
name: "filesystem"
description: "本地文件读写。Invoke when user needs to read, write, or manage local files and directories."
---

# Filesystem

## 功能
本地文件读写。提供文件系统的操作能力。

## 使用场景
- 文件读取
- 文件写入
- 目录管理
- 文件搜索
- 批量文件操作

## 使用方法
当用户需要文件操作时：
1. 读取指定文件内容
2. 写入或更新文件
3. 管理目录结构
4. 搜索和筛选文件
5. 执行批量文件处理
