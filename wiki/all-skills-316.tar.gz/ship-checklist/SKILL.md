---
name: "ship-checklist"
description: "发布前自动巡检，少靠记忆力。Invoke when user needs to perform pre-release checks, validate deployments, or ensure release readiness."
---

# Ship Checklist

## 功能
发布前自动巡检，少靠记忆力。确保发布前的各项检查都已完成。

## 使用场景
- 发布前检查
- 部署验证
- 发布清单管理
- 自动化巡检
- 减少人为遗漏

## 使用方法
当用户准备发布时：
1. 制定发布检查清单
2. 自动执行各项检查
3. 验证代码和配置
4. 确认测试通过
5. 确保发布准备就绪
