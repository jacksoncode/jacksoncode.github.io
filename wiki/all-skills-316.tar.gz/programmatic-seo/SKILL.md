---
name: "programmatic-seo"
description: "Use this when building pages at scale to target keywords. For building pages at scale to target keywords, use schema-markup for structured data, and ai-seo for AI search optimization."
---

# Programmatic SEO

## 功能
规模化生成 SEO 页面。通过程序化方式批量创建针对特定关键词的着陆页。

## 使用场景
- 规模化页面生成
- 关键词着陆页
- 批量 SEO 内容
- 模板化页面创建
- 大规模关键词覆盖

## 使用方法
当用户需要规模化 SEO 时：
1. 研究目标关键词
2. 设计页面模板
3. 批量生成着陆页
4. 优化页面内容
5. 监控排名效果
