---
name: "agent-browser"
description: "Rust 无头浏览器自动化。Invoke when user needs browser automation, web scraping, or programmatic web interaction."
---

# Agent Browser

## 功能
Rust 无头浏览器自动化，用于网页交互、数据抓取和自动化测试。

## 使用场景
- 网页自动化操作
- 数据抓取和采集
- 自动化测试
- 表单填写和提交
- 网页内容监控

## 使用方法
当用户需要浏览器自动化时：
1. 启动无头浏览器
2. 导航到目标网页
3. 执行自动化操作（点击、输入、滚动）
4. 提取所需数据
5. 关闭浏览器并返回结果
