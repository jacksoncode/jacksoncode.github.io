---
name: "skill-vetter"
description: "安全审查官。安装任何第三方 Skill 之前，自动扫描代码，检查权限范围、可疑行为和安全红旗。Invoke before installing any third-party skill to scan code, check permissions, detect malicious behavior, and assess security risks."
---

# Skill Vetter

## 功能
装技能前，先让它过一遍安检。安装任何第三方 Skill 之前，自动扫描代码，检查权限范围、可疑行为和安全红旗。

## 使用场景
- 安装第三方 Skill 前的安全检查
- 审查 Skill 代码的安全性
- 检测恶意代码和数据外泄风险
- 审查权限范围是否合理
- 标记可疑的网络请求

## 核心能力
- 检测恶意代码和数据外泄风险
- 审查权限范围是否合理
- 标记可疑的网络请求
- 给出安装建议：安全 / 警告 / 拒绝

## 使用方法
在安装任何第三方 Skill 之前：
1. 扫描 Skill 代码文件
2. 检查是否有恶意代码或数据外泄风险
3. 审查权限范围是否合理
4. 标记可疑的网络请求
5. 给出安全评估：安全 / 警告 / 拒绝
