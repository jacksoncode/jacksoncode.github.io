---
name: "data-cleaner"
description: "CSV、Excel、JSON批量清洗不手抖。Invoke when user needs to clean, transform, or standardize data in CSV, Excel, or JSON formats."
---

# Data Cleaner

## 功能
CSV、Excel、JSON 批量清洗不手抖。自动化数据清洗和转换。

## 使用场景
- 数据清洗
- 格式转换
- 数据标准化
- 批量处理
- 数据质量提升

## 使用方法
当用户需要清洗数据时：
1. 读取原始数据文件
2. 识别数据质量问题
3. 执行清洗和转换
4. 验证清洗结果
5. 输出干净的数据
