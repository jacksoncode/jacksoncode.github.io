---
name: "backtesting"
description: "策略回测。量化策略验金石，支持过拟合识别与迭代优化。Invoke when user wants to backtest trading strategies, detect overfitting, or optimize strategy parameters."
---

# Backtesting

## 功能
量化策略"验金石"，支持过拟合识别与迭代优化。

## 使用场景
- 交易策略回测
- 过拟合识别
- 策略参数优化
- 绩效评估
- 风险分析

## 使用方法
当用户需要回测策略时：
1. 设定回测参数和规则
2. 运行历史数据回测
3. 分析回测结果和绩效指标
4. 识别过拟合风险
5. 提供优化建议和迭代方向
