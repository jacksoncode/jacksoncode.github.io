---
name: "ci-fixer"
description: "失败流水线先复现，再补最小修复。Invoke when user needs to diagnose and fix CI/CD pipeline failures with minimal, targeted changes."
---

# CI Fixer

## 功能
失败流水线先复现，再补最小修复。帮助快速修复 CI/CD 问题。

## 使用场景
- CI/CD 失败排查
- 流水线修复
- 最小化修复
- 构建问题定位
- 部署故障处理

## 使用方法
当用户需要修复 CI 时：
1. 复现失败的流水线
2. 定位失败原因
3. 制定最小修复方案
4. 验证修复效果
5. 确保流水线通过
