---
name: "self-improving-agent"
description: "自动从错误中学习改进。Invoke when user wants an agent that can learn from mistakes and continuously improve its performance."
---

# Self-Improving Agent

## 功能
自动从错误中学习改进，让 Agent 越用越聪明。

## 使用场景
- 需要持续优化的任务
- 复杂问题的迭代解决
- 从失败中学习的场景
- 自动化流程优化
- 智能体自我进化

## 使用方法
当用户需要自我改进的 Agent 时：
1. 记录每次执行的结果和错误
2. 分析错误原因和改进方向
3. 自动调整策略和方法
4. 持续优化执行效果
5. 形成正向反馈循环
