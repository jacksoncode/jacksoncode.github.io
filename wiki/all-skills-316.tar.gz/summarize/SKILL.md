---
name: "summarize"
description: "网页/PDF/视频一键摘要。Invoke when user needs to summarize web pages, PDF documents, or video content quickly."
---

# Summarize

## 功能
网页/PDF/视频一键摘要，快速提取核心内容。

## 使用场景
- 长文快速阅读
- PDF 文档摘要
- 视频内容提炼
- 信息快速获取
- 内容筛选和过滤

## 使用方法
当用户需要摘要时：
1. 获取目标内容（网页/PDF/视频）
2. 提取关键信息和核心观点
3. 生成简洁的摘要
4. 保留重要细节和数据
5. 提供结构化总结
