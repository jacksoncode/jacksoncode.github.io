---
name: "pptx"
description: "直接生成 pptx 文件，解决从零开始太痛苦的问题。Invoke when user needs to create, edit, or generate PowerPoint presentations (.pptx) programmatically."
---

# PPTX

## 功能
直接生成 pptx 文件，解决从零开始太痛苦的问题。支持自动化创建演示文稿。

## 使用场景
- PPT 自动生成
- 演示文稿创建
- 报告可视化
- 幻灯片批量生成
- 模板化演示

## 使用方法
当用户需要生成 PPT 时：
1. 收集演示内容和结构
2. 设计幻灯片布局
3. 自动生成 pptx 文件
4. 支持图表、图片、动画
5. 提供下载或编辑选项
