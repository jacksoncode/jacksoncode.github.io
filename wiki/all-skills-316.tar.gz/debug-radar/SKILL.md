---
name: "debug-radar"
description: "复现路径、日志线索、假设逐层收敛。Invoke when user needs systematic debugging approach to narrow down root causes through reproduction, logs, and hypothesis testing."
---

# Debug Radar

## 功能
复现路径、日志线索、假设逐层收敛。系统化的调试方法。

## 使用场景
- Bug 定位和修复
- 问题复现
- 日志分析
- 假设验证
- 根因分析

## 使用方法
当用户需要调试时：
1. 建立稳定的复现路径
2. 收集和分析日志线索
3. 提出可能的假设
4. 逐层验证和收敛
5. 定位根因并修复
