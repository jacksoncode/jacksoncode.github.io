---
name: "redis-development"
description: "Redis性能优化和最佳实践。Invoke when working with Redis data structures, Redis Query Engine (RQE), vector search with RedisVL, semantic caching with LangCache, or optimizing Redis performance."
---

# Redis Development

## 功能
Redis 性能优化和最佳实践。涵盖 Redis 数据结构、查询引擎、向量搜索、语义缓存等。

## 使用场景
- Redis 数据结构优化
- Redis Query Engine (RQE)
- 向量搜索 (RedisVL)
- 语义缓存 (LangCache)
- 性能调优

## 使用方法
当用户使用 Redis 时：
1. 优化数据结构设计
2. 使用 Redis Query Engine
3. 实现向量搜索
4. 配置语义缓存
5. 持续性能监控和优化
