---
name: "brainstorming"
description: "给个方向就能帮你炸开十几个思路，一个人脑暴再也不卡壳。Invoke when user needs creative ideation, topic expansion, or help overcoming writer's block before any creative work."
---

# Brainstorming

## 功能
给个方向就能帮你炸开十几个思路，一个人脑暴再也不卡壳。

## 使用场景
- 写作前找灵感
- 创意发散
- 选题拓展
- 克服创作卡壳
- 多角度思考问题

## 使用方法
当用户需要头脑风暴时：
1. 理解用户给出的方向或主题
2. 从不同维度发散思路（角度、受众、形式、情绪）
3. 提供十几个具体的思路方向
4. 每个思路给出简短的说明和可行性评估
5. 帮助用户选出最有价值的方向
