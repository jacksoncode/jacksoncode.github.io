---
name: "changelog-miner"
description: "找出关键改动，补齐遗漏风险。Invoke when user needs to analyze changelogs, identify critical changes, and assess missing update risks."
---

# Changelog Miner

## 功能
找出关键改动，补齐遗漏风险。深入分析变更日志。

## 使用场景
- 变更日志分析
- 关键改动识别
- 风险评估
- 更新影响分析
- 遗漏检查

## 使用方法
当用户需要分析变更时：
1. 读取变更日志
2. 识别关键改动点
3. 评估潜在风险
4. 检查遗漏的更新
5. 提供风险预警
