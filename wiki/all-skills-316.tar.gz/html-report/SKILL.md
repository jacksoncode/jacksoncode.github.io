---
name: "html-report"
description: "Create any self-contained HTML deliverable except slides — research reports, whitepapers, PRDs, dashboards, portfolios, resumes, email templates, data visualizations, and more. Use when the user wants to produce a polished, visually designed HTML page or multi-page site for any purpose."
---

# HTML Report

## 功能
创建任何自包含的 HTML 交付物（除幻灯片外）— 研究报告、白皮书、PRD、仪表板、作品集、简历、邮件模板、数据可视化等。

## 使用场景
- 研究报告
- 白皮书
- 产品需求文档
- 仪表板
- 作品集
- 简历
- 邮件模板

## 使用方法
当用户需要 HTML 报告时：
1. 确定报告类型和目的
2. 设计视觉风格和布局
3. 生成自包含的 HTML 文件
4. 确保零外部依赖
5. 提供精美的视觉呈现
