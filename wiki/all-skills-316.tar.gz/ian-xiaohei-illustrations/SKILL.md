---
name: "ian-xiaohei-illustrations"
description: "中文文章配图生成工具。把文章里的观点、流程、情绪和隐喻转成'小黑'风格插图。Invoke when user needs illustrations for Chinese articles and wants cute, simple 'xiaohei' style images that visualize concepts, processes, or emotions."
---

# ian-xiaohei-illustrations

## 功能
如果你经常写中文文章，这个很适合拿来做正文配图。它不是随便生成一张图，而是把文章里的观点、流程、情绪和隐喻，转成"小黑"风格插图。

## 使用场景
- 中文文章正文配图
- 把抽象观点可视化
- 流程图/步骤图
- 情绪表达插图
- 隐喻性插图

## 使用方法
当用户需要文章配图时：
1. 理解文章中的核心观点、流程或情绪
2. 提取需要可视化的关键元素
3. 生成"小黑"风格的插图
4. 确保插图与文章内容高度相关
5. 提供多种风格或构图供选择
