---
name: "skillclaw"
description: "Skill 进化与去重系统，自动检测冲突并优化。装多了 skill 会打架？这个帮你整理、去重、自动进化。Invoke when user needs to manage, deduplicate, or optimize their installed skills."
---

# SkillClaw

## 功能
Skill 进化与去重系统，自动检测冲突并优化。装多了 skill 会打架？这个帮你整理、去重、自动进化。

## 使用场景
- Skill 管理
- 冲突检测
- 去重优化
- Skill 进化
- 性能优化

## 使用方法
当用户需要管理 skill 时：
1. 扫描已安装的 skills
2. 检测冲突和重复
3. 提供优化建议
4. 自动去重和整理
5. 持续进化 skill 集合
