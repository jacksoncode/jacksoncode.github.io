---
name: "openclaw-stock-kb"
description: "量化知识库。量化入门，策略学习+风控模板直接抄。Invoke when user wants to learn quantitative trading, access strategy templates, or implement risk control frameworks."
---

# OpenClaw Stock KB

## 功能
量化入门，策略学习+风控模板直接抄。

## 使用场景
- 量化交易入门学习
- 策略模板参考
- 风控框架搭建
- 量化知识积累
- 交易系统设计

## 使用方法
当用户需要量化知识时：
1. 提供量化基础知识
2. 分享常用策略模板
3. 提供风控框架参考
4. 讲解策略实现思路
5. 帮助搭建量化交易系统
