---
name: "spec-aligner"
description: "先把目标、范围、验收标准对齐。Invoke when user needs to align project goals, scope, and acceptance criteria before starting implementation."
---

# Spec Aligner

## 功能
先把目标、范围、验收标准对齐。确保项目开始前各方达成一致。

## 使用场景
- 项目启动对齐
- 需求确认
- 范围界定
- 验收标准制定
- 团队共识建立

## 使用方法
当用户需要对齐规格时：
1. 明确项目目标和期望
2. 界定项目范围和边界
3. 制定清晰的验收标准
4. 确保各方理解一致
5. 记录对齐结果
