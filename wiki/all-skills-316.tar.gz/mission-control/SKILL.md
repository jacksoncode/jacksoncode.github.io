---
name: "mission-control"
description: "Agent 舰队编排平台，多 Agent 可视化监控 + 任务调度。同时跑多个 Hermes 实例时，像看仪表盘一样管理所有 Agent。Invoke when user needs to manage multiple agents, orchestrate tasks, or monitor agent fleets."
---

# Mission Control

## 功能
Agent 舰队编排平台，多 Agent 可视化监控 + 任务调度。同时跑多个 Hermes 实例时，像看仪表盘一样管理所有 Agent。

## 使用场景
- 多 Agent 管理
- 任务编排
- 可视化监控
- 舰队调度
- 实例管理

## 使用方法
当用户需要管理 Agent 时：
1. 连接多个 Agent 实例
2. 可视化展示状态
3. 编排任务分配
4. 监控执行进度
5. 统一管理和调度
