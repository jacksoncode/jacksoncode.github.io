---
name: "gbrain"
description: "多团队协作，效率直接翻倍，打工人必备。Invoke when user needs multi-team collaboration, workflow optimization, or productivity enhancement tools."
---

# GBrain

## 功能
多团队协作，效率直接翻倍，打工人必备。11K 星高赞技能。

## 使用场景
- 多团队协作
- 效率提升
- 工作流优化
- 团队沟通
- 项目管理

## 使用方法
当用户需要团队协作时：
1. 建立协作框架
2. 分配任务和角色
3. 优化沟通流程
4. 监控协作效率
5. 持续改进团队表现
