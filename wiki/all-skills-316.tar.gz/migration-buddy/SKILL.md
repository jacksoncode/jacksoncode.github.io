---
name: "migration-buddy"
description: "数据迁移先演练，再安全上线。Invoke when user needs to plan and execute data migrations safely with dry runs and rollback strategies."
---

# Migration Buddy

## 功能
数据迁移先演练，再安全上线。确保数据迁移过程安全可靠。

## 使用场景
- 数据库迁移
- 数据格式转换
- 系统升级
- 数据同步
- 安全上线

## 使用方法
当用户需要数据迁移时：
1. 制定详细的迁移计划
2. 先在测试环境演练
3. 准备回滚方案
4. 执行迁移并监控
5. 验证数据完整性
