---
name: "gh-cli"
description: "GitHub CLI (gh) comprehensive reference for repositories, issues, pull requests, Actions, projects, releases, gists, codespaces, organizations, extensions, and all GitHub operations from the command line."
---

# GitHub CLI (gh)

## 功能
GitHub CLI 综合参考。涵盖仓库、Issue、PR、Actions、项目、发布、gists、codespaces、组织、扩展等所有 GitHub 命令行操作。

## 使用场景
- GitHub 仓库管理
- Issue 和 PR 操作
- Actions 工作流
- 项目管理
- 发布管理
- 组织管理

## 使用方法
当用户需要 GitHub CLI 时：
1. 提供 gh 命令参考
2. 帮助执行 GitHub 操作
3. 管理仓库和协作
4. 自动化 GitHub 工作流
5. 提供最佳实践建议
