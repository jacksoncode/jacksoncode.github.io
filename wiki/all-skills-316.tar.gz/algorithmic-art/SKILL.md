---
name: "algorithmic-art"
description: "Creating algorithmic art using p5.js with seeded randomness and interactive parameter exploration. Use this when users request creating art using code, generative art, algorithmic art, flow fields, or particle systems."
---

# Algorithmic Art

## 功能
Anthropic 官方出品。使用 p5.js 创建生成艺术，支持种子随机性和交互式参数探索。创建原创算法艺术，避免抄袭。

## 使用场景
- 生成艺术创作
- p5.js 粒子系统
- 流场可视化
- 交互式参数探索
- 代码驱动的视觉艺术

## 使用方法
当用户需要创作艺术时：
1. 理解用户的视觉需求
2. 使用 p5.js 设计生成算法
3. 添加种子随机性确保可复现
4. 支持参数调整和探索
5. 输出可运行的代码或图片
