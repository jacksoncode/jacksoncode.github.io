---
name: "frontend-design"
description: "A社官方出品，专注前端界面设计。让页面有审美、有层次，告别模板风格。Invoke when user asks to build web components, pages, artifacts, posters, or applications with high design quality and distinctive visual style."
---

# Frontend Design

## 功能
A社官方出品，专注前端界面设计。让页面有审美、有层次，告别模板风格。

## 使用场景
- 构建网页组件和页面
- 创建精美的前端界面
- 设计有层次感、有审美的页面
- 告别千篇一律的模板风格
- 生成创意、高质量的 UI 设计

## 使用方法
当用户需要前端设计时：
1. 理解用户需求和品牌调性
2. 设计有层次感的视觉结构
3. 使用合适的配色和排版
4. 确保交互细节精致
5. 生成高质量、有辨识度的前端代码
