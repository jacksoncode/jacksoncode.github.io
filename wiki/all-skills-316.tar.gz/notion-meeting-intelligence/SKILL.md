---
name: "notion-meeting-intelligence"
description: "Prepares meeting materials by gathering context from Notion, enriching with Claude research, and creating both an internal pre-read and external agenda saved to Notion. Helps you arrive prepared with comprehensive background and structured meeting docs."
---

# Notion Meeting Intelligence

## 功能
通过从 Notion 收集上下文、用 Claude 研究丰富信息，创建内部预读材料和外部议程，保存到 Notion。

## 使用场景
- 会议准备
- 议程制作
- 背景研究
- 预读材料
- 会议文档管理

## 使用方法
当用户需要准备会议时：
1. 从 Notion 收集相关背景
2. 用 Claude 进行补充研究
3. 创建内部预读文档
4. 制作外部议程
5. 保存到 Notion 便于协作
