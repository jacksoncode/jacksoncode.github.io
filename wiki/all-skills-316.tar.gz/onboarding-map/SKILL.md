---
name: "onboarding-map"
description: "新人先看路线图，再进代码海。Invoke when user needs to create onboarding guides or orientation materials for new team members."
---

# Onboarding Map

## 功能
新人先看路线图，再进代码海。帮助新人快速融入团队。

## 使用场景
- 新人入职引导
- 代码库导航
- 团队流程介绍
- 技术栈说明
- 快速上手

## 使用方法
当用户需要引导新人时：
1. 绘制项目路线图
2. 介绍代码库结构
3. 说明团队流程
4. 提供学习资源
5. 制定上手计划
