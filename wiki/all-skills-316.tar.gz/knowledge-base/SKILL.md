---
name: "knowledge-base"
description: "团队经验沉淀成可复用 Skill。Invoke when user needs to capture, organize, and reuse team knowledge and best practices."
---

# Knowledge Base

## 功能
团队经验沉淀成可复用 Skill。帮助积累和传承团队知识。

## 使用场景
- 团队知识积累
- 最佳实践沉淀
- 经验传承
- 文档化管理
- 知识复用

## 使用方法
当用户需要积累知识时：
1. 收集团队经验和教训
2. 整理最佳实践
3. 创建可复用的 Skill
4. 建立知识库结构
5. 持续更新和维护
