---
name: "hermes-control-interface"
description: "管理后台。Invoke when user needs to manage tasks, monitor progress, or control a system or workflow."
---

# Hermes Control Interface

## 功能
管理后台。提供任务管理和进度监控的控制界面。

## 使用场景
- 任务管理
- 进度监控
- 系统控制
- 工作流管理
- 状态跟踪

## 使用方法
当用户需要管理后台时：
1. 展示当前任务状态
2. 监控执行进度
3. 提供控制选项
4. 管理资源和优先级
5. 生成状态报告
