---
name: "remotion-best-practices"
description: "remotion 视频框架最佳实践，用代码做视频和动画的必装。Invoke when user wants to create videos or animations programmatically using Remotion."
---

# Remotion Best Practices

## 功能
remotion 视频框架最佳实践，用代码做视频和动画的必装。

## 使用场景
- 用代码生成视频
- 动画制作
- 视频模板开发
- 程序化视频生成
- 动态内容视频

## 使用方法
当用户使用 Remotion 时：
1. 遵循 Remotion 框架的最佳实践
2. 优化视频渲染性能
3. 使用合适的组件和 Hooks
4. 确保视频质量和流畅度
5. 提供视频制作的专业建议
