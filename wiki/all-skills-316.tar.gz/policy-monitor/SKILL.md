---
name: "policy-monitor"
description: "政策监控。A股/债市/监管动态实时盯，有大事立马知道。Invoke when user needs to track financial policies, regulatory changes, or market-moving announcements in real-time."
---

# Policy Monitor

## 功能
A股/债市/监管动态实时盯，有大事立马知道。

## 使用场景
- 监控 A 股政策变化
- 跟踪债市监管动态
- 实时获取监管公告
- 政策影响分析
- 重大事件预警

## 使用方法
当用户需要监控政策时：
1. 实时跟踪相关政策发布
2. 分析政策对市场的影响
3. 及时推送重大政策变化
4. 提供政策解读和影响评估
5. 关联相关标的和行业
