---
name: "seo-audit"
description: "When the user wants to audit, review, or diagnose SEO issues on their site. Also use when the user mentions 'SEO audit,' 'technical SEO,' 'why am I not ranking,' 'SEO issues,' 'on-page SEO,' 'meta tags review,' 'SEO health check,' 'my traffic dropped,' 'lost rankings,' 'not showing up in Google,' 'page speed,' 'core web vitals,' 'crawl errors,' or 'indexing issues.'"
---

# SEO Audit

## 功能
全面的 SEO 审计工具。检查页面 SEO 问题，包括技术 SEO、页面优化、核心网页指标、抓取错误、索引问题等。

## 使用场景
- SEO 健康检查
- 技术审计
- 页面优化审查
- 排名问题诊断
- 流量下降分析
- 索引问题排查

## 使用方法
当用户需要 SEO 审计时：
1. 检查页面技术 SEO
2. 审查 meta 标签和结构化数据
3. 分析页面速度和核心指标
4. 检查抓取和索引问题
5. 提供改进建议
