---
name: "code-simplifier"
description: "写完再看一遍，重复逻辑合并成函数。Invoke when user needs to refactor and simplify code by extracting reusable functions and removing duplication."
---

# Code Simplifier

## 功能
写完再看一遍，重复逻辑合并成函数。帮助简化和优化代码。

## 使用场景
- 代码重构
- 重复逻辑提取
- 函数化改造
- 代码简化
- 提高可维护性

## 使用方法
当用户需要简化代码时：
1. 扫描代码中的重复逻辑
2. 提取可复用的函数
3. 合并相似代码块
4. 优化代码结构
5. 确保功能不变的前提下简化
