---
name: "prompt-harness"
description: "固化好提示词，反复跑出稳定结果。Invoke when user needs to create, test, and refine prompts to achieve consistent, reliable AI outputs."
---

# Prompt Harness

## 功能
固化好提示词，反复跑出稳定结果。帮助用户创建和优化提示词。

## 使用场景
- 提示词设计
- 提示词优化
- 结果稳定性提升
- 提示词版本管理
- 批量测试提示词

## 使用方法
当用户需要优化提示词时：
1. 分析当前提示词效果
2. 识别不稳定因素
3. 固化和优化提示词结构
4. 反复测试验证
5. 确保输出稳定可靠
