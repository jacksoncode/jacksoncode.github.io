---
name: "hermes-agent-idea-workflow"
description: "整理想法。Invoke when user needs to organize ideas, structure thoughts, or create a workflow for idea management."
---

# Hermes Agent Idea Workflow

## 功能
整理想法。帮助用户系统化地管理和组织创意。

## 使用场景
- 创意整理
- 想法结构化
- 工作流程搭建
- 头脑风暴后续
- 知识管理

## 使用方法
当用户需要整理想法时：
1. 收集所有相关想法
2. 分类和归类
3. 建立逻辑关系
4. 形成结构化框架
5. 输出清晰的工作流
