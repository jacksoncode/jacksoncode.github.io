---
name: "content-research-writer"
description: "完整写作流程工具。从选题、资料、提纲、引用到初稿，基本能把一篇长文的前期工作串起来，公众号、Newsletter、博客、X长文都能用。Invoke when user needs to write a long-form article and wants help with the entire pre-writing workflow including research, outline, and draft."
---

# content-research-writer

## 功能
适合需要完整写作流程的人。从选题、资料、提纲、引用到初稿，基本能把一篇长文的前期工作串起来，公众号、Newsletter、博客、X长文都能用。

## 使用场景
- 从零开始写一篇长文
- 需要系统化的写作流程支持
- 公众号深度文章
- Newsletter 内容
- 博客长文
- X/Twitter 长线程

## 使用方法
当用户需要写长文时，按以下流程协助：
1. **选题确认** — 帮助明确主题、角度、目标受众
2. **资料搜集** — 搜索相关背景信息、数据、案例
3. **提纲构建** — 搭建文章结构，确定各部分要点
4. **引用整理** — 收集和整理需要引用的来源
5. **初稿撰写** — 基于提纲写出完整初稿
6. **优化建议** — 提供修改和优化方向
