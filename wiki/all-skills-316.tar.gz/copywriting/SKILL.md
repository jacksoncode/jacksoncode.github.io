---
name: "copywriting"
description: "写文案的全能选手，帮你理清结构、优化表达，结构、节奏、表达一起抓。Invoke when user needs to write marketing copy, ads, product descriptions, or any persuasive text."
---

# Copywriting

## 功能
写文案的全能选手，帮你理清结构、优化表达，结构、节奏、表达一起抓。

## 使用场景
- 营销文案撰写
- 广告文案
- 产品介绍
- 品牌故事
- 转化文案

## 使用方法
当用户需要写文案时：
1. 明确文案目标和受众
2. 梳理信息结构和逻辑
3. 优化表达节奏和语气
4. 确保文案有吸引力和说服力
5. 提供多个版本供选择
