---
name: "baoyu-skills"
description: "中文创作者的视觉工具箱。封面图、信息图、结构图、图解都能做，适合给文章做包装，也适合把复杂观点视觉化。Invoke when user needs visual assets for Chinese content including covers, infographics, structure diagrams, or visual explanations."
---

# baoyu-skills

## 功能
中文创作者的视觉工具箱。封面图、信息图、结构图、图解都能做，适合给文章做包装，也适合把复杂观点视觉化。

## 使用场景
- 文章封面图设计
- 信息图制作
- 结构图/思维导图
- 复杂观点图解
- 文章视觉包装
- 数据可视化

## 使用方法
当用户需要视觉设计时：
1. 明确视觉内容的用途（封面/信息图/结构图/图解）
2. 提取需要展示的关键信息
3. 设计清晰、美观的视觉呈现
4. 确保视觉风格与文章调性一致
5. 提供多种设计方案供选择
