---
name: "json-canvas"
description: "Create and edit JSON Canvas files (.canvas) with nodes, edges, groups, and connections. Use when working with .canvas files, creating visual canvases, mind maps, flowcharts, or when the user mentions Canvas files in Obsidian."
---

# JSON Canvas

## 功能
创建和编辑 JSON Canvas 文件 (.canvas)，支持节点、边、组和连接。

## 使用场景
- Canvas 文件创建
- 可视化画布
- 思维导图
- 流程图
- Obsidian Canvas

## 使用方法
当用户需要 Canvas 时：
1. 创建 .canvas 文件
2. 添加节点和连接
3. 设计分组和布局
4. 创建思维导图或流程图
5. 在 Obsidian 中使用
