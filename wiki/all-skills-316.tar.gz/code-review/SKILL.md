---
name: "code-review"
description: "多 Agent 并行审查，置信度过滤减少假阳性。Invoke when user needs comprehensive code review with multiple perspectives and confidence-based filtering."
---

# Code Review

## 功能
多 Agent 并行审查，置信度过滤减少假阳性。提供高质量的代码审查。

## 使用场景
- 代码审查
- 多视角评估
- 减少误报
- 提高代码质量
- 团队协作审查

## 使用方法
当用户需要代码审查时：
1. 启动多个审查 Agent
2. 并行分析代码问题
3. 使用置信度过滤结果
4. 减少假阳性报告
5. 提供准确的改进建议
