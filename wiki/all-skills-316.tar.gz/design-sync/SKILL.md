---
name: "design-sync"
description: "UI、交互、数据状态同步检查。Invoke when user needs to ensure consistency between UI design, interactions, and data state across the application."
---

# Design Sync

## 功能
UI、交互、数据状态同步检查。确保设计一致性。

## 使用场景
- UI 设计一致性检查
- 交互逻辑验证
- 数据状态同步
- 设计稿对比
- 跨平台一致性

## 使用方法
当用户需要检查设计时：
1. 对比 UI 设计和实现
2. 检查交互逻辑一致性
3. 验证数据状态同步
4. 发现不一致之处
5. 提供修复建议
