---
name: "schema-markup"
description: "Add structured data to web pages. Use this when adding JSON-LD, Microdata, or RDFa structured data to HTML pages for rich results in search engines."
---

# Schema Markup

## 功能
为网页添加结构化数据标记。支持 JSON-LD、Microdata、RDFa 格式，帮助搜索引擎理解页面内容并展示富媒体搜索结果。

## 使用场景
- 结构化数据添加
- JSON-LD 标记
- 富媒体搜索结果
- 搜索引擎优化
- 内容语义化

## 使用方法
当用户需要结构化数据时：
1. 分析页面内容类型
2. 选择合适的 Schema 类型
3. 生成 JSON-LD 或其他格式
4. 嵌入到 HTML 页面中
5. 验证结构化数据正确性
