---
name: "release-notes"
description: "从diff里提炼用户能看懂的更新。Invoke when user needs to generate user-friendly release notes from code changes or diffs."
---

# Release Notes

## 功能
从 diff 里提炼用户能看懂的更新。自动生成清晰的发布说明。

## 使用场景
- 发布说明生成
- 版本更新文档
- 用户沟通
- 变更总结
- 产品迭代记录

## 使用方法
当用户需要发布说明时：
1. 分析代码 diff
2. 提取关键变更
3. 转化为用户友好的语言
4. 分类整理更新内容
5. 生成完整的发布说明
