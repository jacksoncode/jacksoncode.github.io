---
name: "screenshot-qa"
description: "桌面和移动端都过一遍视觉检查。Invoke when user needs to perform visual QA across desktop and mobile platforms using screenshots."
---

# Screenshot QA

## 功能
桌面和移动端都过一遍视觉检查。确保跨平台视觉一致性。

## 使用场景
- 跨平台视觉检查
- 响应式设计验证
- UI 一致性确认
- 视觉回归测试
- 多设备兼容性

## 使用方法
当用户需要视觉检查时：
1. 在桌面端截取截图
2. 在移动端截取截图
3. 对比视觉差异
4. 检查响应式布局
5. 生成视觉检查报告
