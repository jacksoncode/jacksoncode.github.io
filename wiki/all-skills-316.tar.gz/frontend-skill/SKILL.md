---
name: "frontend-skill"
description: "Use when the task asks for a visually strong landing page, website, app, prototype, demo, or game UI. This skill enforces restrained composition, image-led hierarchy, cohesive content structure, and tasteful motion while avoiding generic cards, weak branding, and UI clutter."
---

# Frontend Skill

## 功能
A社官方出品。用于构建视觉强烈的落地页、网站、应用、原型、演示或游戏 UI。强调克制的构图、图像主导的层次结构、连贯的内容结构和优雅的动作。

## 使用场景
- 视觉强烈的落地页
- 网站设计
- 应用界面
- 原型和演示
- 游戏 UI

## 使用方法
当用户需要前端设计时：
1. 采用克制的构图原则
2. 建立图像主导的层次结构
3. 保持内容结构连贯
4. 添加优雅的动作效果
5. 避免通用卡片和 UI 杂乱
