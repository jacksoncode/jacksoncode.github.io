---
name: "stock-data-skill"
description: "高频数据。做短线/日内交易必备，高频数据帮你验证策略。Invoke when user needs high-frequency trading data, intraday data, or real-time market data for short-term trading strategies."
---

# Stock Data Skill

## 功能
做短线/日内交易必备，高频数据帮你验证策略。

## 使用场景
- 短线交易数据支持
- 日内交易分析
- 高频策略验证
- 实时行情监控
- Tick 级数据分析

## 使用方法
当用户需要高频数据时：
1. 获取高频行情数据
2. 分析盘口和资金流向
3. 验证短线交易策略
4. 监控实时异动
5. 提供交易信号参考
