---
name: "chart-visualization"
description: "Intelligently selects the most suitable chart type from 26 available options, extracts parameters based on detailed specifications, and generates a chart image using a JavaScript script."
---

# Chart Visualization

## 功能
从 26 种可用图表类型中智能选择最合适的，基于详细规格提取参数，使用 JavaScript 脚本生成图表图像。

## 使用场景
- 数据可视化
- 图表生成
- 报告配图
- 数据展示
- 分析图表

## 使用方法
当用户需要图表时：
1. 分析数据特征
2. 选择最合适的图表类型
3. 提取和配置参数
4. 生成图表图像
5. 确保图表清晰易读
