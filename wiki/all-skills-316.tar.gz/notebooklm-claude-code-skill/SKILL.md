---
name: "notebooklm-claude-code-skill"
description: "资料型写作工具。更适合基于已有资料库来写作，能减少胡编乱造，适合行业研究、课程稿、深度文章和长文整理。Invoke when user wants to write based on existing documents, research materials, or knowledge base rather than generating from scratch."
---

# NotebookLM Claude Code Skill

## 功能
资料型写作者可以重点看看。它更适合基于已有资料库来写作，能减少胡编乱造，适合行业研究、课程稿、深度文章和长文整理。

## 使用场景
- 基于已有资料进行写作
- 行业研究报告
- 课程稿和教案
- 深度文章整理
- 长文资料汇总
- 减少AI幻觉，确保内容有据可依

## 使用方法
当用户需要基于资料写作时：
1. 先收集和整理用户提供的资料
2. 分析资料中的关键信息和观点
3. 基于资料构建文章框架
4. 写作时严格引用资料内容
5. 标注信息来源，确保可追溯
6. 补充资料间的逻辑连接
