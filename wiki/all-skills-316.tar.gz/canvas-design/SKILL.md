---
name: "canvas-design"
description: "一句话出海报配图。Invoke when user needs to quickly generate posters, banners, or visual designs from a simple description."
---

# Canvas Design

## 功能
一句话出海报配图，快速生成视觉设计内容。

## 使用场景
- 海报设计
- 配图生成
- 视觉内容创作
- 社交媒体图片
- 快速设计原型

## 使用方法
当用户需要设计海报或配图时：
1. 理解用户的一句话描述
2. 提取设计需求和风格偏好
3. 生成符合描述的视觉设计
4. 提供多种设计选项
5. 支持快速迭代和调整
