---
name: "better-auth-best-practices"
description: "做用户登录注册系统的，Better Auth 官方出品，OAuth、验证码、密钥登录一站式搞定。Invoke when implementing authentication, user registration, OAuth, or security features in web applications."
---

# Better Auth Best Practices

## 功能
做用户登录注册系统的，Better Auth 官方出品，OAuth、验证码、密钥登录一站式搞定。

## 使用场景
- 用户认证系统
- 登录注册功能
- OAuth 集成
- 多因素认证
- 安全策略实施

## 使用方法
当用户需要认证功能时：
1. 设计安全的认证流程
2. 集成 OAuth 提供商
3. 实现验证码和密钥登录
4. 配置会话管理和 JWT
5. 确保认证系统的安全性
