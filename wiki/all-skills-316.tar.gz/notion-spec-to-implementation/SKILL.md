---
name: "notion-spec-to-implementation"
description: "Turns product or tech specs into concrete Notion tasks that Claude code can implement. Breaks down spec pages into detailed implementation plans with clear tasks, acceptance criteria, and progress tracking to guide development from requirements to completion."
---

# Notion Spec to Implementation

## 功能
将产品或技术规格文档转化为 Claude Code 可实现的具体 Notion 任务。拆解规格页面为详细的实施计划。

## 使用场景
- 规格文档拆解
- 任务分解
- 验收标准制定
- 进度跟踪
- 需求到实现

## 使用方法
当用户需要实施规划时：
1. 读取规格文档
2. 拆解为具体任务
3. 制定验收标准
4. 创建 Notion 任务
5. 跟踪实施进度
