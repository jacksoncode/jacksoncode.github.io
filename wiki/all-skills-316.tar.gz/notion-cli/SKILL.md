---
name: "notion-cli"
description: "Use the Notion CLI (ntn) to interact with the Notion API, manage workers, and upload files. Use when the user asks to 'call the Notion API', 'deploy a worker', 'upload a file to Notion', 'create a page', 'query a database', or any task involving the 'ntn' command."
---

# Notion CLI

## 功能
通过 Notion CLI (ntn) 与 Notion API 交互，管理工作器和上传文件。

## 使用场景
- Notion API 调用
- Worker 管理
- 文件上传
- 页面创建
- 数据库查询

## 使用方法
当用户需要操作 Notion 时：
1. 使用 ntn 命令行工具
2. 调用 Notion API
3. 管理和部署 Worker
4. 上传文件到 Notion
5. 查询和操作数据库
