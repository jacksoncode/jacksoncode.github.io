---
name: "building-native-ui"
description: "Expo 官方出品，做移动端想要原生手感的装这个，标签栏、手势、动画都有。Invoke when building mobile apps with Expo, implementing native-feeling UI components, gestures, animations, or navigation patterns."
---

# Building Native UI

## 功能
Expo 官方出品，做移动端想要原生手感的装这个，标签栏、手势、动画都有。

## 使用场景
- Expo 移动端开发
- 原生风格 UI 组件
- 手势交互
- 流畅动画
- 原生导航模式

## 使用方法
当用户开发移动端 UI 时：
1. 使用 Expo 的原生组件
2. 实现流畅的手势交互
3. 添加自然的动画效果
4. 设计符合平台规范的界面
5. 确保原生般的用户体验
