---
name: "find-skills"
description: "自动发现和安装新技能。Invoke when user wants to discover and install new skills to extend capabilities."
---

# Find Skills

## 功能
自动发现和安装新技能，帮助用户找到并安装适合当前任务的 skill。

## 使用场景
- 寻找特定功能的 skill
- 扩展 Agent 能力
- 发现新的工具和工作流
- 技能管理和更新
- 能力增强

## 使用方法
当用户需要发现新技能时：
1. 分析用户当前需求和场景
2. 搜索匹配的 skill
3. 评估 skill 的适用性和质量
4. 帮助用户安装和配置
5. 提供使用建议
