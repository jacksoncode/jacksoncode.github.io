---
name: "open-design"
description: "31个可组合技能 + 129个设计系统，本地优先开源设计工具。不用开 Figma 就能出稿，Hermes 直接生成 UI，独立开发者效率神器。Invoke when user needs design tools, UI generation, or design system management without relying on proprietary software."
---

# Open Design

## 功能
31个可组合技能 + 129个设计系统，本地优先开源设计工具。不用开 Figma 就能出稿，Hermes 直接生成 UI，独立开发者效率神器。

## 使用场景
- UI 设计生成
- 设计系统管理
- 开源设计工具
- 独立开发效率提升
- 本地优先设计

## 使用方法
当用户需要设计时：
1. 选择合适的设计技能
2. 应用设计系统
3. 生成 UI 稿
4. 本地编辑和调整
5. 输出设计成果
