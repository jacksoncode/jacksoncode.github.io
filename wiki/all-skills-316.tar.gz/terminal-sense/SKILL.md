---
name: "terminal-sense"
description: "读日志、跑命令、把异常翻成线索。Invoke when user needs to analyze terminal logs, run diagnostic commands, or translate errors into actionable insights."
---

# Terminal Sense

## 功能
读日志、跑命令、把异常翻成线索。帮助从终端输出中提取有用信息。

## 使用场景
- 日志分析
- 命令执行和诊断
- 异常排查
- 错误信息解读
- 系统状态检查

## 使用方法
当用户需要分析终端时：
1. 读取相关日志文件
2. 执行诊断命令
3. 分析异常和错误
4. 提取关键线索
5. 提供解决方案建议
