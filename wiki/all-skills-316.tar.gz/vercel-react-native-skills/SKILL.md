---
name: "vercel-react-native-skills"
description: "做移动端 App 的装这个，React Native + Expo 性能优化，列表卡顿、动画掉帧都能治。Invoke when building React Native components, optimizing list performance, implementing animations, or working with native platform APIs."
---

# Vercel React Native Skills

## 功能
做移动端 App 的装这个，React Native + Expo 性能优化，列表卡顿、动画掉帧都能治。

## 使用场景
- React Native 应用开发
- Expo 项目优化
- 列表性能优化
- 动画流畅度提升
- 移动端性能调优

## 使用方法
当用户开发 React Native 应用时：
1. 优化列表渲染性能
2. 提升动画流畅度
3. 减少不必要的重渲染
4. 使用原生模块优化关键路径
5. 遵循移动端最佳实践
