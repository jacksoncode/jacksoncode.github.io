---
name: "data-analysis"
description: "全链路数据分析(探查→体检→执行→报告)。Invoke when user uploads Excel (.xlsx/.xls) or CSV files and wants to perform data analysis, generate statistics, create summaries, pivot tables, SQL queries, or any form of structured data exploration."
---

# Data Analysis

## 功能
全链路数据分析（探查→体检→执行→报告）。支持多 sheet Excel、聚合、过滤、连接、导出 CSV/JSON/Markdown。

## 使用场景
- Excel/CSV 数据分析
- 统计报告生成
- 数据透视表
- SQL 查询
- 数据清洗和转换

## 使用方法
当用户需要数据分析时：
1. 加载和探查数据
2. 数据质量体检
3. 执行分析操作
4. 生成统计报告
5. 导出结果文件
