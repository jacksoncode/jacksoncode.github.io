---
name: "khazix-skills"
description: "公众号长文和万字研究报告写作工具。写作流偏重，不是随手写一篇短文那种，更适合AI热点分析、深度拆解和观点型长文。Invoke when user needs to write in-depth WeChat official account articles, research reports, or analytical long-form content about AI and tech topics."
---

# khazix-skills

## 功能
适合做公众号长文和万字研究报告。里面的写作流偏重，不是随手写一篇短文那种，更适合AI热点分析、深度拆解和观点型长文。

## 使用场景
- 公众号深度长文
- 万字研究报告
- AI热点分析
- 深度拆解类文章
- 观点型长文
- 需要系统写作流程的重度内容

## 使用方法
当用户需要写深度长文时：
1. 明确文章类型（热点分析/深度拆解/观点论述）
2. 构建深度分析框架
3. 收集充分的数据和案例支撑
4. 按逻辑层次展开论述
5. 确保每个观点都有论据支持
6. 结尾给出明确的结论或行动建议
