---
name: "web-design-guidelines"
description: "Vercel 官方网页设计规范。帮助审查 UI 代码是否符合 Web Interface Guidelines，消除 AI 生成页面的廉价感。Invoke when asked to review UI, check accessibility, audit design, review UX, or check site against best practices."
---

# Web Design Guidelines

## 功能
Vercel 官方网页设计规范。做出来的页面不再有 AI 的廉价感，遵循专业的设计标准和最佳实践。

## 使用场景
- 审查 UI 代码是否符合设计规范
- 检查网页可访问性 (Accessibility)
- 审计设计质量
- 检查 UX 体验
- 消除 AI 生成页面的廉价感

## 使用方法
当用户需要审查或优化网页设计时：
1. 检查页面布局是否符合设计规范
2. 审查可访问性（颜色对比度、焦点状态、语义化 HTML）
3. 评估视觉层次和信息架构
4. 检查响应式设计
5. 提供具体的改进建议
