---
name: "humanizer-zh"
description: "中文写作去AI味工具。帮助处理空话、套话、三段式、过度排比等问题，让稿子更像真人写出来的。Invoke when user writes Chinese content that sounds robotic or AI-generated and wants it to feel more natural and human."
---

# Humanizer-zh

## 功能
中文写作者很实用的去AI味工具。它不是简单改几个词，而是会帮你处理空话、套话、三段式、过度排比这些问题，让稿子更像真人写出来的。

## 使用场景
- 写完中文文章后发现语气太"AI"
- 需要让内容更自然、更有个人风格
- 处理套话、空话、过度排比等问题
- 让公众号文章、博客、Newsletter 更像真人写作

## 使用方法
当用户要求去AI味或让文章更自然时：
1. 分析原文中的AI痕迹（套话、三段式、过度排比、空洞表达）
2. 保留核心观点和信息
3. 用更口语化、有个人风格的表达替换
4. 适当加入具体细节、个人感受、不完美的表达
5. 避免过于工整的排比和结构
