---
name: "issue-gardener"
description: "把模糊需求修剪成可执行任务。Invoke when user needs to refine vague requirements into clear, actionable tasks."
---

# Issue Gardener

## 功能
把模糊需求修剪成可执行任务。帮助细化和澄清需求。

## 使用场景
- 需求细化
- 任务拆解
- 模糊需求澄清
- 可执行化改造
- 工作量评估

## 使用方法
当用户需要处理需求时：
1. 分析原始需求的模糊点
2. 澄清不确定的部分
3. 拆分为具体任务
4. 定义明确的验收条件
5. 确保任务可执行
