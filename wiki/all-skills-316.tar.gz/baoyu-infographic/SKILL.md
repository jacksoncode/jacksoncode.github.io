---
name: "baoyu-infographic"
description: "数据和信息一键变信息图，20种版式随便挑，汇报、发帖都能用。Invoke when user needs to convert data or information into infographics, charts, or visual reports."
---

# Baoyu Infographic

## 功能
数据和信息一键变信息图，20种版式随便挑，汇报、发帖都能用。

## 使用场景
- 数据可视化
- 信息图制作
- 汇报材料设计
- 社交媒体发帖配图
- 复杂信息简洁呈现

## 使用方法
当用户需要信息图时：
1. 分析用户提供的原始数据或信息
2. 选择最适合的版式（20种可选）
3. 设计清晰的信息层级
4. 生成美观的信息图
5. 确保信息准确、易读
