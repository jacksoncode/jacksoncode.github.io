---
name: "marketing-skills"
description: "访问23个营销模块，提供CRO、SEO、文案、分析、发布、广告及社交媒体领域的清晰策略。Invoke when user needs marketing strategy, CRO, SEO, copywriting, analytics, publishing, advertising, or social media strategy."
---

# Marketing Skills

## 功能
访问 23 个营销模块，提供 CRO、SEO、文案、分析、发布、广告及社交媒体领域的清晰策略。策略大脑，多维分析驱动增长。

## 使用场景
- CRO 优化
- SEO 策略
- 营销文案
- 数据分析
- 内容发布
- 广告投放
- 社交媒体运营

## 使用方法
当用户需要营销策略时：
1. 分析营销目标和受众
2. 选择合适的营销模块
3. 制定清晰的策略方案
4. 执行并监控效果
5. 持续优化和调整
