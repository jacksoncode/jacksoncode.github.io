---
name: "larry"
description: "自动化TikTok幻灯片营销，支持竞品调研、AI生图、文字叠加、Postiz发布及分析追踪。Invoke when user needs TikTok marketing automation, competitor research, AI image generation, text overlay, or social media publishing and analytics."
---

# Larry

## 功能
自动化 TikTok 幻灯片营销，支持竞品调研、AI 生图、文字叠加、Postiz 发布及分析追踪。内容策略分析-文案-追踪一条龙。

## 使用场景
- TikTok 幻灯片营销
- 竞品调研
- AI 生图
- 文字叠加设计
- Postiz 发布
- 分析追踪
- 内容策略全流程

## 使用方法
当用户需要 TikTok 营销时：
1. 进行竞品调研和分析
2. 使用 AI 生成相关图片
3. 添加文字叠加效果
4. 通过 Postiz 发布内容
5. 追踪分析效果数据
