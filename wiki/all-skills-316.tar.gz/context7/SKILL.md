---
name: "context7"
description: "实时文档拉取。Invoke when user needs to fetch and integrate real-time documentation or context from external sources."
---

# Context7

## 功能
实时文档拉取。动态获取最新文档和上下文信息。

## 使用场景
- 实时文档获取
- 最新信息拉取
- 上下文更新
- 知识库同步
- 动态内容集成

## 使用方法
当用户需要实时文档时：
1. 识别需要的文档来源
2. 实时拉取最新内容
3. 整合到当前上下文
4. 确保信息的时效性
5. 提供基于最新文档的回答
