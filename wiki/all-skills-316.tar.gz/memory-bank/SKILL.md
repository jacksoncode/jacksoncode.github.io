---
name: "memory-bank"
description: "持久记忆系统。Invoke when user needs to store, retrieve, or manage persistent memory across sessions."
---

# Memory Bank

## 功能
持久记忆系统。帮助用户在不同会话间保持记忆和上下文。

## 使用场景
- 跨会话记忆保持
- 长期信息存储
- 上下文恢复
- 知识积累
- 个性化体验

## 使用方法
当用户需要持久记忆时：
1. 存储关键信息和偏好
2. 在后续会话中恢复记忆
3. 更新和扩展记忆内容
4. 确保记忆的一致性和准确性
5. 提供基于记忆的个性化服务
