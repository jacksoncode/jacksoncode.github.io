---
name: "hermes-atlas"
description: "找方向。Invoke when user needs to find direction, set goals, or establish a clear path for a project or task."
---

# Hermes Atlas

## 功能
找方向。帮助用户明确目标和路径。

## 使用场景
- 项目方向确定
- 目标设定
- 路径规划
- 战略思考
- 方向校准

## 使用方法
当用户需要找方向时：
1. 分析当前状况和需求
2. 明确核心目标
3. 探索可能的路径
4. 评估各路径的可行性
5. 确定最佳方向
