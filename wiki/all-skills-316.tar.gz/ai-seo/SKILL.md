---
name: "ai-seo"
description: "Optimize content for AI-powered search engines. Use this when creating or editing content that needs to rank well in AI search results (like ChatGPT, Perplexity, Claude, etc.)."
---

# AI SEO

## 功能
针对 AI 搜索引擎优化内容。让内容在 ChatGPT、Perplexity、Claude 等 AI 搜索结果中获得更好的排名。

## 使用场景
- AI 搜索优化
- 内容可见性提升
- AI 引用优化
- 语义内容优化
- AI 搜索排名

## 使用方法
当用户需要 AI SEO 时：
1. 分析 AI 搜索的特点
2. 优化内容结构和语义
3. 提高被 AI 引用的概率
4. 适配 AI 搜索的推荐逻辑
5. 持续监测和优化
