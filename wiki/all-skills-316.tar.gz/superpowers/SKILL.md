---
name: "superpowers"
description: "AI项目经理，先想后做。Invoke when user needs project management, task planning, or structured thinking before execution."
---

# Superpowers

## 功能
AI项目经理，先想后做。帮助用户在执行前进行充分思考和规划。

## 使用场景
- 项目管理
- 任务规划
- 结构化思考
- 执行前的策略制定
- 复杂项目的分解和安排

## 使用方法
当用户需要项目管理时：
1. 分析项目目标和约束条件
2. 制定详细的项目计划
3. 分解任务并设定优先级
4. 评估风险和资源需求
5. 提供执行路线图和时间表
