---
name: "ralph-loop"
description: "Claude 想提前收工？Hook 拦截塞回去直到做完。Invoke when user needs to ensure Claude completes tasks fully without stopping prematurely."
---

# Ralph Loop

## 功能
Claude 想提前收工？Hook 拦截塞回去直到做完。确保任务完整执行。

## 使用场景
- 防止任务提前终止
- 确保完整执行
- 长任务持续运行
- 自动重试机制
- 任务完成保证

## 使用方法
当用户需要确保任务完成时：
1. 监控任务执行状态
2. 检测提前终止倾向
3. 自动拦截并继续执行
4. 确保所有步骤完成
5. 验证最终结果
