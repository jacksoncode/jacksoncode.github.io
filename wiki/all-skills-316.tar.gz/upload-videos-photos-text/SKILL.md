---
name: "upload-videos-photos-text"
description: "通过 Upload-Post API 向 TikTok、Instagram、YouTube、LinkedIn 等平台发布内容。Invoke when user needs to publish content to multiple social media platforms."
---

# Upload Videos, Photos & Text

## 功能
通过 Upload-Post API 向 TikTok、Instagram、YouTube、LinkedIn 等平台发布内容。一键多平台发布，高效触达全球受众。

## 使用场景
- 多平台内容发布
- TikTok 发布
- Instagram 发布
- YouTube 发布
- LinkedIn 发布
- 社交媒体管理

## 使用方法
当用户需要发布内容时：
1. 准备发布内容（视频/图片/文字）
2. 选择目标平台
3. 通过 API 发布内容
4. 监控发布状态
5. 追踪发布效果
