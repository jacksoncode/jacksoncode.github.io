---
name: "obsidian-cli"
description: "Obsidian笔记库深度集成。Invoke when user needs to interact with Obsidian vaults, manage notes, search content, or develop plugins and themes."
---

# Obsidian CLI

## 功能
Obsidian 笔记库深度集成。2.5K Stars 高赞技能。让 AI 读你的笔记库。

## 使用场景
- Obsidian 笔记管理
- 笔记内容搜索
- 插件开发
- 主题开发
- 知识库集成

## 使用方法
当用户需要 Obsidian 时：
1. 连接 Obsidian 笔记库
2. 搜索和读取笔记内容
3. 管理笔记和任务
4. 开发插件和主题
5. 与 AI 深度集成
