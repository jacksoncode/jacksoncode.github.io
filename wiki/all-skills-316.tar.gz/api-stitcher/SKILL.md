---
name: "api-stitcher"
description: "串接口、补类型、把边界缝牢。Invoke when user needs to integrate APIs, fill type definitions, or secure boundaries between services."
---

# API Stitcher

## 功能
串接口、补类型、把边界缝牢。帮助整合 API 并确保类型安全。

## 使用场景
- API 集成
- 类型定义补充
- 服务边界处理
- 接口契约维护
- 跨服务调用

## 使用方法
当用户需要整合 API 时：
1. 分析接口文档和契约
2. 补充缺失的类型定义
3. 处理边界情况和错误
4. 确保接口调用安全
5. 验证集成后的功能
