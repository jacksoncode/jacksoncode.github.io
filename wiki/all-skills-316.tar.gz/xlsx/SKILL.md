---
name: "xlsx"
description: "Excel数据自动处理。Invoke when user needs to process, analyze, or generate Excel spreadsheets (.xlsx) programmatically."
---

# XLSX

## 功能
Excel数据自动处理，支持数据的读取、分析和生成。

## 使用场景
- Excel 数据处理
- 数据分析报告
- 表格自动生成
- 数据清洗和转换
- 批量数据处理

## 使用方法
当用户需要处理 Excel 数据时：
1. 读取或导入 Excel 文件
2. 进行数据清洗和分析
3. 生成统计图表和报告
4. 支持公式计算和数据透视
5. 导出处理后的 Excel 文件
