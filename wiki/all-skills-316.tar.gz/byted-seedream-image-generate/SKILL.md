---
name: "byted-seedream-image-generate"
description: "Generate high-quality images from text prompts using Volcano Engine Seedream models. Supports multiple artistic styles and aspect ratios. Use this skill when users want to create images from text descriptions, generate artwork in various styles, create visual content for creative projects, or need AI-powered image generation capabilities."
---

# Byted Seedream Image Generate

## 功能
通过火山引擎 Seedream 模型从文本提示生成高质量图像。支持多种艺术风格和宽高比。

## 使用场景
- 文本生成图像
- 艺术创作
- 创意项目视觉内容
- AI 图像生成
- 多风格图像

## 使用方法
当用户需要生成图像时：
1. 理解用户的图像描述
2. 选择合适的艺术风格
3. 使用 Seedream 模型生成
4. 调整宽高比和参数
5. 输出高质量图像
