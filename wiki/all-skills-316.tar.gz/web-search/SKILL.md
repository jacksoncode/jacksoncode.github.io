---
name: "web-search"
description: "实时联网搜索。Invoke when user needs to search the web for current information, news, or data."
---

# Web Search

## 功能
实时联网搜索。获取最新的网络信息和数据。

## 使用场景
- 实时信息搜索
- 新闻获取
- 数据查询
- 趋势分析
- 事实核查

## 使用方法
当用户需要搜索时：
1. 构建搜索查询
2. 执行实时网络搜索
3. 筛选和整理结果
4. 提取关键信息
5. 提供准确及时的答案
