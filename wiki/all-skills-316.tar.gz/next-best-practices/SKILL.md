---
name: "next-best-practices"
description: "Vercel 出的 Next.js 专属 skill，做全栈项目装这个，路由、缓存、RSC 这些坑帮你绕过。Invoke when building Next.js applications, handling routing, caching, React Server Components, or full-stack features."
---

# Next Best Practices

## 功能
Vercel 出的 Next.js 专属 skill，做全栈项目装这个，路由、缓存、RSC 这些坑帮你绕过。

## 使用场景
- Next.js 应用开发
- 全栈项目构建
- 路由和缓存优化
- React Server Components
- App Router 使用

## 使用方法
当用户使用 Next.js 时：
1. 正确使用 App Router 和文件系统路由
2. 优化数据获取和缓存策略
3. 合理使用 React Server Components
4. 处理服务端和客户端组件边界
5. 遵循 Next.js 最佳实践
