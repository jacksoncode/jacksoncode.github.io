---
name: "nano-banana-pro"
description: "通过 Gemini 3 Pro Image (Nano Banana Pro) 生成或编辑图像。Invoke when user needs high-quality image generation and editing for content creation."
---

# Nano Banana Pro

## 功能
通过 Gemini 3 Pro Image (Nano Banana Pro) 生成或编辑图像。高质量图像生成与编辑，让内容更吸睛。

## 使用场景
- 高质量图像生成
- 图像编辑
- 内容配图
- 视觉设计
- 创意图像

## 使用方法
当用户需要图像生成时：
1. 理解用户的图像需求
2. 使用 Gemini 3 Pro Image 生成图像
3. 根据反馈编辑和调整
4. 输出高质量图像
5. 确保图像符合内容需求
