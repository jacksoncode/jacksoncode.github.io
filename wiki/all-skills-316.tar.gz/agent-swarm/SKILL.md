---
name: "agent-swarm"
description: "多代理分工，探索、实现、验证并行跑。Invoke when user needs to distribute complex tasks across multiple specialized agents working in parallel."
---

# Agent Swarm

## 功能
多代理分工，探索、实现、验证并行跑。利用多个 Agent 协同完成复杂任务。

## 使用场景
- 复杂任务分解
- 多代理并行执行
- 探索与实现分离
- 验证与开发并行
- 效率提升

## 使用方法
当用户需要多代理协作时：
1. 分析任务并分解为子任务
2. 为每个子任务分配专门的 Agent
3. 并行执行探索和实现
4. 验证结果的正确性
5. 汇总最终结果
