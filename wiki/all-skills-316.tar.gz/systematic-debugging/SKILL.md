---
name: "systematic-debugging"
description: "系统性排查问题的思维框架，写方案、做分析的时候特别好用。Invoke when user needs to systematically analyze problems, debug issues, or build structured analytical frameworks."
---

# Systematic Debugging

## 功能
系统性排查问题的思维框架，写方案、做分析的时候特别好用。

## 使用场景
- 系统性排查问题
- 写方案和分析报告
- 故障诊断
- 逻辑梳理
- 根因分析

## 使用方法
当用户需要系统排查问题时：
1. 定义问题的边界和范围
2. 建立排查框架和检查清单
3. 逐步缩小问题范围
4. 验证假设并记录结果
5. 给出根因和解决方案
