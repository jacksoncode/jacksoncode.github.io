---
name: "pr-narrator"
description: "代码改了什么，为什么改，一眼说清。Invoke when user needs to write clear, informative pull request descriptions that explain what changed and why."
---

# PR Narrator

## 功能
代码改了什么，为什么改，一眼说清。帮助编写清晰的 PR 描述。

## 使用场景
- PR 描述编写
- 代码变更说明
- 变更原因阐述
- 代码审查辅助
- 团队协作沟通

## 使用方法
当用户需要写 PR 时：
1. 分析代码变更内容
2. 总结修改了什么
3. 解释为什么修改
4. 标注关键变更点
5. 提供清晰的变更说明
