---
name: "copy-editing"
description: "初稿写完丢给它，七遍精修帮你从'能看'打磨到'好看'。Invoke when user has a draft that needs polishing, refinement, or professional editing to improve readability and impact."
---

# Copy Editing

## 功能
初稿写完丢给它，七遍精修帮你从"能看"打磨到"好看"。

## 使用场景
- 初稿精修
- 提升文章质量
- 优化表达
- 打磨细节
- 从合格到优秀

## 使用方法
当用户需要编辑润色时：
1. 通读全文，把握整体基调
2. 第一遍：检查结构和逻辑
3. 第二遍：优化段落衔接
4. 第三遍：精炼句子表达
5. 第四遍：调整节奏和语气
6. 第五遍：检查用词准确性
7. 第六遍：打磨开头和结尾
8. 第七遍：最终通读和微调
