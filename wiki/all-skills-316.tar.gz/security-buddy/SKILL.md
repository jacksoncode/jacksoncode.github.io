---
name: "security-buddy"
description: "输入、权限、密钥、依赖逐项扫。Invoke when user needs to perform security audits, check permissions, scan dependencies, or review security configurations."
---

# Security Buddy

## 功能
输入、权限、密钥、依赖逐项扫。全面的安全检查。

## 使用场景
- 安全审计
- 权限检查
- 密钥管理
- 依赖扫描
- 漏洞检测

## 使用方法
当用户需要安全检查时：
1. 检查输入验证
2. 审查权限配置
3. 扫描密钥泄露风险
4. 检查依赖漏洞
5. 提供安全改进建议
