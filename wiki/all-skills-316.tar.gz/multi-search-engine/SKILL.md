---
name: "multi-search-engine"
description: "多引擎聚合搜索。标的/政策/研报一键搜，消除信息盲区。Invoke when user needs to search for financial data, policies, research reports, or comprehensive information across multiple sources."
---

# Multi Search Engine

## 功能
多引擎聚合搜索。标的/政策/研报一键搜，消除信息盲区。

## 使用场景
- 搜索金融标的资料
- 查找政策信息
- 搜索研报和分析报告
- 消除信息盲区
- 综合多源信息

## 使用方法
当用户需要搜索金融相关信息时：
1. 同时使用多个搜索引擎
2. 聚合不同来源的信息
3. 交叉验证信息准确性
4. 整理成结构化报告
5. 标注信息来源
