---
name: "notion-knowledge-capture"
description: "Transforms conversations and discussions into structured documentation pages in Notion. Captures insights, decisions, and knowledge from chat context, formats appropriately, and saves to wikis or databases with proper organization and linking for easy discovery."
---

# Notion Knowledge Capture

## 功能
将对话和讨论转化为 Notion 中的结构化文档页面。从聊天上下文中捕获洞察、决策和知识。

## 使用场景
- 对话转文档
- 知识沉淀
- 决策记录
- 会议纪要
- Notion 知识库管理

## 使用方法
当用户需要知识捕获时：
1. 从对话中提取关键信息
2. 结构化整理内容
3. 格式化为 Notion 页面
4. 保存到合适的知识库位置
5. 添加链接和标签便于检索
