---
name: "retrospective-bot"
description: "复盘问题，产出下次行动项。Invoke when user needs to conduct retrospectives, analyze past work, and generate actionable improvements."
---

# Retrospective Bot

## 功能
复盘问题，产出下次行动项。帮助团队持续改进。

## 使用场景
- 项目复盘
- 迭代回顾
- 问题分析
- 改进计划
- 团队成长

## 使用方法
当用户需要复盘时：
1. 收集项目数据和反馈
2. 分析成功和失败因素
3. 识别改进机会
4. 制定具体行动项
5. 跟踪改进效果
