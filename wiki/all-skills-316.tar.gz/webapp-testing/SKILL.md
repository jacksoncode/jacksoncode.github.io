---
name: "webapp-testing"
description: "A社官方出品，帮你自动跑测试、截图、找 bug，不用手动一个个点了。Invoke when interacting with and testing local web applications using Playwright. Supports verifying frontend functionality, debugging UI behavior, capturing browser screenshots, and viewing browser logs."
---

# Webapp Testing

## 功能
A社官方出品，帮你自动跑测试、截图、找 bug，不用手动一个个点了。

## 使用场景
- 前端功能测试
- UI 行为调试
- 浏览器截图对比
- 自动化测试
- Bug 发现和定位

## 使用方法
当用户需要测试 Web 应用时：
1. 使用 Playwright 编写自动化测试
2. 捕获页面截图进行对比
3. 验证前端功能和交互
4. 查看浏览器日志和错误
5. 提供测试报告和改进建议
