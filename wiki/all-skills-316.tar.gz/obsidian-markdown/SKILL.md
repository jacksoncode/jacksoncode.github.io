---
name: "obsidian-markdown"
description: "Create and edit Obsidian Flavored Markdown with wikilinks, embeds, callouts, properties, and other Obsidian-specific syntax. Use when working with .md files in Obsidian, or when the user mentions wikilinks, callouts, frontmatter, tags, embeds, or Obsidian notes."
---

# Obsidian Markdown

## 功能
创建和编辑 Obsidian 风格的 Markdown，支持 wikilinks、embeds、callouts、properties 等 Obsidian 特有语法。

## 使用场景
- Obsidian 笔记创建
- Wikilinks 使用
- Callouts 语法
- Frontmatter 属性
- 标签和嵌入

## 使用方法
当用户需要 Obsidian Markdown 时：
1. 使用 Obsidian 特有语法
2. 添加 wikilinks 和嵌入
3. 使用 callouts 和属性
4. 确保与 Obsidian 兼容
5. 优化笔记结构
