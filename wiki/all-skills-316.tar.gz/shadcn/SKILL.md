---
name: "shadcn"
description: "Manages shadcn components and projects — adding, searching, fixing, debugging, styling, and composing UI. Provides project context, component docs, and usage examples. Applies when working with shadcn/ui, component registries, presets, --preset codes, or any project with a components.json file."
---

# Shadcn

## 功能
管理 shadcn 组件和项目 — 添加、搜索、修复、调试、样式和组合 UI。提供项目上下文、组件文档和使用示例。

## 使用场景
- shadcn/ui 组件管理
- 组件搜索和添加
- 样式调试
- UI 组合
- 组件注册表
- presets 配置

## 使用方法
当用户使用 shadcn/ui 时：
1. 提供项目上下文
2. 搜索和推荐组件
3. 帮助添加和配置组件
4. 调试样式问题
5. 组合复杂 UI
