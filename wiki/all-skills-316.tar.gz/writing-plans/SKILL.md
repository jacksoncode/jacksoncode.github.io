---
name: "writing-plans"
description: "写长文之前先过一遍这个，帮你把混乱的想法理成清晰的大纲。Invoke when user has a spec or requirements for a multi-step task, before touching code or writing long-form content."
---

# Writing Plans

## 功能
写长文之前先过一遍这个，帮你把混乱的想法理成清晰的大纲。

## 使用场景
- 写长文前的规划
- 整理混乱的想法
- 构建清晰大纲
- 多步骤任务规划
- 内容结构设计

## 使用方法
当用户需要写长文或规划任务时：
1. 收集用户的所有想法和素材
2. 梳理核心主题和主线
3. 构建层次分明的结构
4. 确定各部分的内容要点
5. 输出清晰可执行的大纲
