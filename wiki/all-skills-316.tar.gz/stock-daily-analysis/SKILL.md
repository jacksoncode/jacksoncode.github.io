---
name: "stock-daily-analysis"
description: "每日复盘。自动一键整理当日行情，辅助交易决策。Invoke when user needs daily market recap, trading day summary, or post-market analysis to support trading decisions."
---

# Stock Daily Analysis

## 功能
自动一键整理当日行情，辅助交易决策。

## 使用场景
- 每日行情复盘
- 交易决策辅助
- 市场热点追踪
- 持仓表现分析
- 次日交易计划

## 使用方法
当用户需要每日复盘时：
1. 整理当日大盘走势
2. 分析板块轮动情况
3. 追踪热点个股
4. 评估持仓表现
5. 提供次日交易参考
