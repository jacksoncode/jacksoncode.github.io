---
name: "pdf"
description: "PDF读写、表单填写、OCR识别。Invoke when user needs to extract text and tables from PDFs, create new PDFs, merge/split documents, fill forms, or perform OCR."
---

# PDF

## 功能
Anthropic 官方出品。集成 pypdf、pdfplumber、reportlab 等库，支持文本表格提取、扫描件OCR、合并拆分、表单填写、加密解密、添加水印。

## 使用场景
- PDF 文本和表格提取
- 扫描件 OCR 识别
- PDF 合并和拆分
- 表单填写
- 加密解密
- 添加水印
- 从 Word/HTML 生成 PDF

## 使用方法
当用户需要处理 PDF 时：
1. 识别 PDF 类型（文本/扫描件/表单）
2. 按需调用底层库
3. 执行提取、创建或编辑操作
4. 输出处理后的 PDF 文件
