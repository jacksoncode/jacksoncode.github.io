---
name: "awesome-hermes"
description: "全网最全生态导航，找什么项目一搜就有。Invoke when user needs to discover Hermes ecosystem resources, projects, or community tools."
---

# Awesome Hermes

## 功能
全网最全生态导航，找什么项目一搜就有。1.9K 星高赞技能。

## 使用场景
- 生态资源发现
- 项目搜索
- 社区工具查找
- 资源导航
- 知识库探索

## 使用方法
当用户需要找资源时：
1. 搜索目标项目或工具
2. 浏览生态资源列表
3. 筛选和推荐相关项目
4. 提供详细信息和链接
5. 帮助用户快速找到所需
