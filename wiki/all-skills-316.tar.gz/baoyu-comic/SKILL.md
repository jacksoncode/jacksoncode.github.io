---
name: "baoyu-comic"
description: "宝玉出的漫画风格 Skill。把文章变成漫画风的配图。Invoke when user wants to convert article content into comic-style illustrations or manga-like visuals."
---

# Baoyu Comic

## 功能
宝玉出的漫画风格 Skill。把文章变成漫画风的配图。

## 使用场景
- 文章漫画风配图
- 把文字内容可视化
- 生成有趣的漫画风格插图
- 社交媒体漫画内容
- 教程/步骤的漫画化呈现

## 使用方法
当用户需要漫画风格配图时：
1. 理解文章的核心内容和情节
2. 提取关键场景和角色
3. 生成漫画风格的视觉呈现
4. 保持故事性和趣味性
5. 确保画面与文字内容呼应
