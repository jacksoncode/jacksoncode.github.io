---
name: "vercel-react-best-practices"
description: "Vercel 官方出品，React 最佳实践全封装，前端必装，装了 Agent 写出来的代码质量直接上一个台阶。Invoke when writing, reviewing, or refactoring React code to ensure optimal performance patterns."
---

# Vercel React Best Practices

## 功能
Vercel 官方出品，React 最佳实践全封装，前端必装，装了 Agent 写出来的代码质量直接上一个台阶。

## 使用场景
- React 组件开发
- 性能优化
- 代码质量提升
- 最佳实践遵循
- 前端项目构建

## 使用方法
当用户写 React 代码时：
1. 遵循 React 最佳实践和性能优化原则
2. 使用合适的 Hooks 和组件模式
3. 避免常见的性能陷阱
4. 确保代码可维护性和可测试性
5. 提供符合 Vercel 标准的代码建议
