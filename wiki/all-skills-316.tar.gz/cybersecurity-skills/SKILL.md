---
name: "cybersecurity-skills"
description: "754个结构化网安技能，完整映射 MITRE ATT&CK 框架。安全方向最全的 Skill 集，渗透测试、安全审计、漏洞分析一条龙。Invoke when user needs cybersecurity expertise, penetration testing, security auditing, or vulnerability analysis."
---

# Cybersecurity Skills

## 功能
754个结构化网安技能，完整映射 MITRE ATT&CK 框架。安全方向最全的 Skill 集，渗透测试、安全审计、漏洞分析一条龙。

## 使用场景
- 网络安全
- 渗透测试
- 安全审计
- 漏洞分析
- 威胁检测

## 使用方法
当用户需要安全技能时：
1. 识别安全需求
2. 选择对应的网安技能
3. 执行渗透测试或审计
4. 分析漏洞和威胁
5. 提供安全建议
