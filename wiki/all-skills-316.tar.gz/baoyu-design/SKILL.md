---
name: "baoyu-design"
description: "终端里直接用Claude生成UI mockup，不需要打开Figma，不需要联网。Invoke when user needs to generate UI mockups, design prototypes, or visual layouts directly in the terminal."
---

# Baoyu Design

## 功能
在终端里直接用 Claude 生成 UI mockup。不需要打开 Figma，不需要联网，直接在终端里搞定。

## 使用场景
- UI 原型设计
- 界面 mockup 生成
- 快速视觉验证
- 设计方案展示
- 产品原型沟通

## 使用方法
当用户需要 UI 设计时：
1. 描述界面需求和布局
2. Claude 直接生成 UI mockup
3. 在终端中预览效果
4. 快速迭代和调整
5. 无需额外设计工具
