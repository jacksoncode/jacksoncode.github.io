---
name: "planning-with-files"
description: "把规划写进文件，上下文压缩了也不丢状态。Invoke when user needs to persist plans, requirements, or project state to files to survive context window limitations."
---

# Planning with Files

## 功能
把规划写进文件，上下文压缩了也不丢状态。确保项目计划和状态持久化存储。

## 使用场景
- 长项目规划持久化
- 防止上下文丢失
- 多阶段任务管理
- 项目状态跟踪
- 需求文档维护

## 使用方法
当用户需要持久化规划时：
1. 将规划内容写入文件
2. 定期更新项目状态
3. 在上下文压缩时从文件恢复
4. 确保关键信息不丢失
5. 维护项目文档的完整性
