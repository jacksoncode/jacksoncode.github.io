---
name: "baoyu-cover-image"
description: "中文圈最火的封面图 Skill。丢篇文章进去就出封面，写文章省事太多了。Invoke when user needs to generate cover images for Chinese articles, blog posts, or social media content."
---

# Baoyu Cover Image

## 功能
中文圈最火的封面图 Skill。丢篇文章进去就出封面，写文章省事太多了。

## 使用场景
- 文章封面图生成
- 公众号封面
- 博客文章头图
- 社交媒体封面
- 快速生成与文章内容匹配的封面

## 使用方法
当用户需要生成封面图时：
1. 分析文章的核心主题和关键词
2. 提取文章的情绪基调和视觉风格
3. 生成与文章内容高度匹配的封面图
4. 确保封面具有吸引力和辨识度
5. 提供多种风格选择
