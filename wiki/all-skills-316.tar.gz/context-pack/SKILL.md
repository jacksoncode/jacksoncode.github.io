---
name: "context-pack"
description: "把需求、约束、接口一次性喂清楚。Invoke when user needs to gather and organize project requirements, constraints, and interfaces before starting implementation."
---

# Context Pack

## 功能
把需求、约束、接口一次性喂清楚。确保在项目开始前收集完整的上下文信息。

## 使用场景
- 项目启动前的需求梳理
- 约束条件收集
- 接口文档整理
- 上下文信息打包
- 减少沟通成本

## 使用方法
当用户开始新项目时：
1. 收集完整的需求描述
2. 梳理技术约束和限制
3. 整理接口定义和契约
4. 打包所有上下文信息
5. 确保信息完整后再开始实现
