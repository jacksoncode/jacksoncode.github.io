---
name: "refactor-lens"
description: "小步重构，行为不漂移。Invoke when user needs to refactor code incrementally while preserving existing behavior and avoiding regressions."
---

# Refactor Lens

## 功能
小步重构，行为不漂移。确保重构过程中功能保持不变。

## 使用场景
- 代码重构
- 技术债务清理
- 代码优化
- 设计模式引入
- 保持行为一致性

## 使用方法
当用户需要重构时：
1. 识别重构目标和范围
2. 制定小步重构计划
3. 每次只做一个改动
4. 验证行为没有漂移
5. 逐步完成重构目标
