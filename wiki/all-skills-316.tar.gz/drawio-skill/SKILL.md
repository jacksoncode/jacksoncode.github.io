---
name: "drawio-skill"
description: "一句话生成 draw.io 流程图 / UML 图 / 架构图。产品经理和技术人最爱，说人话就能出图，不用手动拖拽画框。Invoke when user needs to create flowcharts, UML diagrams, or architecture diagrams from natural language descriptions."
---

# Drawio Skill

## 功能
一句话生成 draw.io 流程图 / UML 图 / 架构图。产品经理和技术人最爱，说人话就能出图，不用手动拖拽画框。

## 使用场景
- 流程图生成
- UML 图绘制
- 架构图设计
- 快速原型图
- 技术文档配图

## 使用方法
当用户需要画图时：
1. 理解用户的描述和需求
2. 生成对应的 draw.io 格式图表
3. 确保图表清晰准确
4. 提供可编辑的源文件
5. 支持多种图表类型
