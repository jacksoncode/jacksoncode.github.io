---
name: "playwright-scout"
description: "自动打开网页，截图定位UI问题。Invoke when user needs automated browser testing, UI regression detection, or visual verification of web applications."
---

# Playwright Scout

## 功能
自动打开网页，截图定位UI问题。使用 Playwright 进行自动化 UI 检查。

## 使用场景
- UI 回归检测
- 自动化截图对比
- 视觉问题定位
- 网页功能验证
- 跨浏览器测试

## 使用方法
当用户需要检查 UI 时：
1. 自动打开目标网页
2. 截取页面截图
3. 对比基准截图
4. 定位 UI 差异和问题
5. 生成检查报告
