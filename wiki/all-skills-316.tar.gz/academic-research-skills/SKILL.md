---
name: "academic-research-skills"
description: "学术研究技能包，覆盖从研究规划、文献调研、论文撰写、引用核查、同行评审模拟、修订回稿全流程。Invoke when user needs academic research assistance, paper writing, literature review, or citation management."
---

# Academic Research Skills

## 功能
学术研究技能包，覆盖从研究规划、文献调研、论文撰写、引用核查、同行评审模拟、修订回稿全流程。26K Stars 高赞技能。

## 使用场景
- 学术研究
- 文献调研
- 论文撰写
- 引用核查
- 同行评审模拟
- 修订回稿

## 使用方法
当用户需要学术研究时：
1. 制定研究规划
2. 进行文献调研
3. 撰写学术论文
4. 核查引用准确性
5. 模拟同行评审
6. 处理修订和回稿
