---
name: "notion-research-documentation"
description: "Searches across your Notion workspace, synthesizes findings from multiple pages, and creates comprehensive research documentation saved as new Notion pages. Turns scattered information into structured reports with proper citations and actionable insights."
---

# Notion Research Documentation

## 功能
搜索 Notion 工作区，综合多个页面信息，创建全面的研究文档保存为新 Notion 页面。

## 使用场景
- Notion 内容搜索
- 信息综合整理
- 研究报告生成
- 知识整合
- 可操作洞察提取

## 使用方法
当用户需要研究文档时：
1. 搜索 Notion 工作区
2. 综合多个页面信息
3. 创建结构化研究报告
4. 添加引用和来源
5. 保存为新 Notion 页面
