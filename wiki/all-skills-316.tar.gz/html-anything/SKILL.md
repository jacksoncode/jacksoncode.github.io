---
name: "html-anything"
description: "Markdown、文案、文章转HTML工具。可以把内容转成HTML页面、海报、卡片和PNG。适合做杂志风文章、知识卡片、小红书图文和分享图。Invoke when user wants to convert markdown or text content into HTML pages, posters, cards, or images."
---

# html-anything

## 功能
可以把 Markdown、文案、文章转成 HTML 页面、海报、卡片和 PNG。适合做杂志风文章、知识卡片、小红书图文和分享图。

## 使用场景
- Markdown 转精美 HTML 页面
- 文章转海报
- 知识卡片制作
- 小红书图文生成
- 分享图制作
- 杂志风排版

## 使用方法
当用户需要转换内容为HTML或图片时：
1. 分析原始内容的结构和重点
2. 选择合适的排版风格（杂志风/卡片/海报）
3. 设计美观的HTML布局
4. 确保排版适合目标平台（小红书/公众号/网页）
5. 生成可直接使用或导出的HTML/图片
